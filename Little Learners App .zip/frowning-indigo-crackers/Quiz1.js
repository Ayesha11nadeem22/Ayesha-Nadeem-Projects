import React, { useState } from "react";
import { StyleSheet, Text, View, TouchableOpacity, ScrollView, Modal } from "react-native";

export default function Quiz1Screen({ navigation }) {
  const [unlockedLevel, setUnlockedLevel] = useState(1);
  const [currentLevel, setCurrentLevel] = useState(0);
  const [index, setIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [selected, setSelected] = useState(null);
  const [modalVisible, setModalVisible] = useState(false);
  const [popupTitle, setPopupTitle] = useState("");
  const [popupMessage, setPopupMessage] = useState("");
  const [showPrize, setShowPrize] = useState(false);

  // ❇️ QUIZ DATA
  const quizData = {
    1: [
      { q: "Who is the last Prophet of Islam?", o: ["Adam (A.S)", "Isa (A.S)", "Muhammad ﷺ", "Nooh (A.S)"], a: 2 },
      { q: "How many pillars of Islam?", o: ["3", "4", "5", "6"], a: 2 },
      { q: "Holy book of Islam?", o: ["Bible", "Torah", "Quran", "Zabur"], a: 2 },
      { q: "Where was Prophet Muhammad ﷺ born?", o: ["Makkah", "Medina", "Taif", "Jerusalem"], a: 0 },
      { q: "Which month is fasting obligatory?", o: ["Shaban", "Ramadan", "Rajab", "Muharram"], a: 1 },
      { q: "First revelation was in which cave?", o: ["Hira", "Thawr", "Safa", "Marwah"], a: 0 },
      { q: "How many times do Muslims pray daily?", o: ["3", "4", "5", "6"], a: 2 },
      { q: "Direction of prayer is called?", o: ["Qibla", "Salah", "Zakat", "Hajj"], a: 0 },
      { q: "The night journey of Prophet ﷺ is called?", o: ["Isra and Mi’raj", "Hijra", "Hajj", "Umrah"], a: 0 },
      { q: "Which angel brought revelation?", o: ["Jibreel", "Mikaeel", "Israfeel", "Azrael"], a: 0 }
    ],
    2: [
      { q: "Where is Kaaba located?", o: ["Madina", "Makkah", "Taif", "Jeddah"], a: 1 },
      { q: "Which city did Prophet ﷺ migrate to?", o: ["Makkah", "Medina", "Taif", "Jerusalem"], a: 1 },
      { q: "Islamic calendar is based on?", o: ["Solar", "Lunar", "Gregorian", "Julian"], a: 1 },
      { q: "Muslims perform Hajj in which month?", o: ["Shaban", "Ramadan", "Dhul-Hijjah", "Muharram"], a: 2 },
      { q: "Which day is Eid-ul-Fitr celebrated?", o: ["1 Shawwal", "10 Dhul-Hijjah", "12 Rabi-ul-Awwal", "27 Rajab"], a: 0 },
      { q: "What is Zakat?", o: ["Prayer", "Charity", "Fasting", "Hajj"], a: 1 },
      { q: "Fasting means?", o: ["Sawm", "Zakat", "Hajj", "Salah"], a: 0 },
      { q: "Holy book revealed to Prophet Musa (A.S)?", o: ["Torah", "Quran", "Zabur", "Bible"], a: 0 },
      { q: "How many daily prayers are obligatory?", o: ["3", "4", "5", "6"], a: 2 },
      { q: "Which month do Muslims fast in?", o: ["Rajab", "Ramadan", "Shaban", "Safar"], a: 1 }
    ],
    3: [
      { q: "Who was the first Prophet of Islam?", o: ["Isa (A.S)", "Adam (A.S)", "Nooh (A.S)", "Ibrahim (A.S)"], a: 1 },
      { q: "What is Qibla?", o: ["Mosque", "Direction of Prayer", "Fasting", "Charity"], a: 1 },
      { q: "Where is Hajj performed?", o: ["Madina", "Makkah", "Taif", "Riyadh"], a: 1 },
      { q: "Who is father of Prophet Musa (A.S)?", o: ["Imran", "Amin", "Harun", "Zakariya"], a: 0 },
      { q: "Which prophet was swallowed by a whale?", o: ["Yunus (A.S)", "Nooh (A.S)", "Ibrahim (A.S)", "Musa (A.S)"], a: 0 },
      { q: "How many chapters in Quran?", o: ["114", "110", "112", "120"], a: 0 },
      { q: "The first mosque built by Prophet ﷺ?", o: ["Masjid al-Haram", "Masjid Quba", "Masjid al-Aqsa", "Masjid Nabawi"], a: 1 },
      { q: "Which angel will blow the trumpet on Qiyamah?", o: ["Jibreel", "Mikaeel", "Israfeel", "Azrael"], a: 2 },
      { q: "What is the meaning of Salah?", o: ["Charity", "Prayer", "Fasting", "Pilgrimage"], a: 1 },
      { q: "Prophet Isa (A.S) was born in?", o: ["Jerusalem", "Makkah", "Bethlehem", "Medina"], a: 2 }
    ],
    4: [
      { q: "How many parts (Juz) are in the Quran?", o: ["20", "25", "30", "40"], a: 2 },
      { q: "Masjid is a place for?", o: ["Study", "Prayer", "Play", "Sleep"], a: 1 },
      { q: "Which prophet built the Ark?", o: ["Nooh (A.S)", "Ibrahim (A.S)", "Musa (A.S)", "Isa (A.S)"], a: 0 },
      { q: "Night prayer is called?", o: ["Salah", "Tahajjud", "Sawm", "Zakat"], a: 1 },
      { q: "Which sea did Allah split for Musa (A.S)?", o: ["Red Sea", "Dead Sea", "Arabian Sea", "Mediterranean"], a: 0 },
      { q: "Who was thrown into fire by his people?", o: ["Ibrahim (A.S)", "Musa (A.S)", "Yunus (A.S)", "Isa (A.S)"], a: 0 },
      { q: "Prophet Muhammad ﷺ married Khadija (R.A) at age?", o: ["25", "20", "30", "35"], a: 0 },
      { q: "Jannah means?", o: ["Hell", "Paradise", "Earth", "Mosque"], a: 1 },
      { q: "Prophet Yusuf (A.S) was known for?", o: ["Patience", "Wisdom", "Strength", "Bravery"], a: 0 },
      { q: "What is the meaning of Hijrah?", o: ["Migration", "Prayer", "Fasting", "Charity"], a: 0 }
    ],
    5: [
      { q: "Who was the first Khalifa after Prophet Muhammad ﷺ?", o: ["Umar", "Ali", "Abu Bakr", "Usman"], a: 2 },
      { q: "What does “Islam” literally mean?", o: ["Peace", "Obedience", "Love", "Respect"], a: 0 },
      { q: "Eid-ul-Fitr comes after which month?", o: ["Hajj", "Ramadan", "Shaban", "Safar"], a: 1 },
      { q: "Prophet Muhammad ﷺ received first revelation at age?", o: ["40", "35", "30", "25"], a: 0 },
      { q: "Which prophet had a staff and split the sea?", o: ["Musa (A.S)", "Ibrahim (A.S)", "Yunus (A.S)", "Isa (A.S)"], a: 0 },
      { q: "How many companions pledged allegiance at Aqabah?", o: ["12", "73", "75", "20"], a: 1 },
      { q: "The Quran was revealed over?", o: ["20 years", "23 years", "25 years", "30 years"], a: 1 },
      { q: "Which battle was first fought by Muslims?", o: ["Badr", "Uhud", "Khyber", "Tabuk"], a: 0 },
      { q: "Who compiled the Quran?", o: ["Abu Bakr & Zaid", "Umar & Ali", "Uthman & Zaid", "Ali & Abu Bakr"], a: 2 },
      { q: "Which Prophet’s son was Ismail (A.S)?", o: ["Ibrahim (A.S)", "Adam (A.S)", "Nooh (A.S)", "Yusuf (A.S)"], a: 0 }
    ]
  };

  // ⭐ Show Levels
  const LevelScreen = () => (
    <View style={styles.center}>
      <Text style={styles.heading}>📘 Islamic Quiz</Text>
      <View style={styles.grid}>
        {[1, 2, 3, 4, 5].map((lv) =>
          lv <= unlockedLevel ? (
            <TouchableOpacity key={lv} style={styles.levelBox} onPress={() => startLevel(lv)}>
              <Text style={styles.levelText}>Level {lv}</Text>
            </TouchableOpacity>
          ) : (
            <View key={lv} style={styles.lockedBox}>
              <Text style={styles.lockedText}>🔒 Level {lv}</Text>
            </View>
          )
        )}
      </View>
    </View>
  );

  function startLevel(lv) {
    setCurrentLevel(lv);
    setIndex(0);
    setScore(0);
    setSelected(null);
  }

  function chooseOption(i) {
    setSelected(i);
  }

  function nextQuestion() {
    if (selected === null) return;

    if (selected === quizData[currentLevel][index].a) {
      setScore(score + 1);
    }

    setSelected(null);

    if (index + 1 < quizData[currentLevel].length) {
      setIndex(index + 1);
    } else {
      finishLevel();
    }
  }

  function finishLevel() {
    if (score >= 7) {
      if (currentLevel === 5) {
        setShowPrize(true);
        setUnlockedLevel(6);
        return;
      }

      if (currentLevel === unlockedLevel && unlockedLevel < 5) {
        setUnlockedLevel(unlockedLevel + 1);
      }

      showPopup(`Level ${currentLevel} Passed ✅`, `Score: ${score}/10\nNext Level Unlocked`);
    } else {
      showPopup(`Level ${currentLevel} Failed ❌`, `Score: ${score}/10\nTry Again`);
    }
    setCurrentLevel(0);
  }

  function showPopup(title, message) {
    setPopupTitle(title);
    setPopupMessage(message);
    setModalVisible(true);
  }

  return (
    <View style={styles.container}>
      {currentLevel === 0 && !showPrize ? (
        <LevelScreen />
      ) : !showPrize ? (
        <View style={styles.quizBox}>
          <Text style={styles.levelTitle}>Level {currentLevel}</Text>

          <Text style={styles.question}>
            Q{index + 1}. {quizData[currentLevel][index].q}
          </Text>

          {quizData[currentLevel][index].o.map((opt, i) => (
            <TouchableOpacity
              key={i}
              style={[styles.option, selected === i ? styles.selectedOption : null]}
              onPress={() => chooseOption(i)}
            >
              <Text>{opt}</Text>
            </TouchableOpacity>
          ))}

          <TouchableOpacity style={styles.nextBtn} onPress={nextQuestion}>
            <Text style={{ color: "white" }}>Next</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <View style={styles.center}>
          <Text style={styles.prizeTitle}>🏆 WELL DONE! 🏆</Text>
          <Text style={styles.stars}>⭐⭐⭐</Text>
          <Text style={styles.prizeText}>You passed all Levels! 🌙</Text>
          <Text style={styles.prizeText}>Allah bless you 🤍</Text>
        </View>
      )}

      {/* Popup Modal */}
      <Modal transparent={true} visible={modalVisible} animationType="fade">
        <View style={styles.modalBg}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>{popupTitle}</Text>
            <Text style={styles.modalMsg}>{popupMessage}</Text>
            <TouchableOpacity onPress={() => setModalVisible(false)} style={styles.modalBtn}>
              <Text style={{ color: "white", fontWeight: "bold" }}>Continue</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* Back Button */}
      <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
        <Text style={styles.backBtnText}>← Back To Quizzes</Text>
      </TouchableOpacity>
    </View>
  );
}

// ⭐ STYLES
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#e3f2fd", paddingTop: 50 },
  center: { alignItems: "center", paddingTop: 40 },
  heading: { fontSize: 28, fontWeight: "bold", marginBottom: 40 },
  grid: { width: "90%", flexDirection: "row", flexWrap: "wrap", justifyContent: "center" },
  levelBox: { width: "40%", backgroundColor: "#0c417e", padding: 20, borderRadius: 15, margin: 10 },
  levelText: { color: "white", fontSize: 18, textAlign: "center" },
  lockedBox: { width: "40%", backgroundColor: "#dfe6e9", padding: 20, borderRadius: 15, margin: 10 },
  lockedText: { color: "#636e72", textAlign: "center" },
  quizBox: { padding: 20 },
  levelTitle: { fontSize: 22, fontWeight: "bold", textAlign: "center", marginBottom: 20 },
  question: { fontSize: 20, marginVertical: 20 },
  option: { padding: 12, backgroundColor: "#dfe6e9", marginVertical: 8, borderRadius: 10 },
  selectedOption: { backgroundColor: "#a0c4ff" },
  nextBtn: { backgroundColor: "#235083", padding: 10, borderRadius: 10, alignItems: "center", marginTop: 20 },
  prizeTitle: { fontSize: 32, fontWeight: "bold", color: "#2d3436" },
  stars: { fontSize: 45, marginVertical: 15 },
  prizeText: { fontSize: 20, color: "#2d3436" },
  modalBg: { flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "center", alignItems: "center" },
  modalContent: { backgroundColor: "white", padding: 25, width: "80%", borderRadius: 15, alignItems: "center" },
  modalTitle: { fontSize: 22, fontWeight: "bold" },
  modalMsg: { fontSize: 17, marginVertical: 10, textAlign: "center" },
  modalBtn: { backgroundColor: "#0c417e", paddingVertical: 10, paddingHorizontal: 25, borderRadius: 10, marginTop: 10 },

  // ✅ Back Button Styles (thoda neeche)
backBtn: {
  position: "absolute",
  top: "65%", // center se neeche
  alignSelf: "center",
  backgroundColor: "#0c417e",
  paddingVertical: 12,
  paddingHorizontal: 28,
  borderRadius: 30,
  elevation: 6
},
backBtnText: {
  color: "white",
  fontSize: 16,
  fontWeight: "bold"
}
});
