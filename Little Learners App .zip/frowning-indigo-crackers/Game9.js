import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { WebView } from 'react-native-webview';
import { LinearGradient } from 'expo-linear-gradient';

export default function Game9Screen({ navigation }) {
  const injectedJS = `
    (function () {
      const style = document.createElement('style');
      style.innerHTML = \`
        html, body {
          margin: 0 !important;
          padding: 0 !important;
          background: black !important;
          height: 100% !important;
          overflow: auto !important;
        }

        iframe {
          width: 100% !important;
          height: 100% !important;
          min-height: 100% !important;
        }
      \`;
      document.head.appendChild(style);
    })();
    true;
  `;

  return (
    <LinearGradient
      colors={['#2a5298', '#6a11cb', '#ff9a76']}
      style={styles.container}
    >
      {/* 🔹 HEADER */}
      <View style={styles.header}>
        <Text style={styles.title}>✨ Game 9: Prayer Puzzle 🙏 ✨</Text>
        <Text style={styles.subtitle}>
          🧩 Put together the prayer puzzle and learn the beautiful steps of Salah!
        </Text>
      </View>

      {/* 🔹 GAME */}
      <View style={styles.gameWrapper}>
        <WebView
          // 👇 Direct Educaplay link use karo (not islam4kids iframe)
          source={{ uri: 'https://www.educaplay.com/game/27292926-salaat_the_prayer.html' }}
          injectedJavaScript={injectedJS}
          javaScriptEnabled
          domStorageEnabled
          startInLoadingState
          originWhitelist={['*']}
          mixedContentMode="always"
          scalesPageToFit={true}
          nestedScrollEnabled={true}
          style={styles.webview}
        />
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },

  header: {
    paddingTop: 40,
    paddingBottom: 10,
    alignItems: 'center',
  },

  title: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'center',
  },

  subtitle: {
    fontSize: 13,
    color: '#fff',
    textAlign: 'center',
    marginTop: 5,
    paddingHorizontal: 15,
  },

  back: {
    marginTop: 8,
    fontSize: 14,
    color: '#fff',
    fontWeight: 'bold',
    textDecorationLine: 'underline',
  },

  gameWrapper: {
    flex: 1,
    width: '100%',
    backgroundColor: '#000',
  },

  webview: {
    flex: 1,
    width: '100%',
    backgroundColor: '#000',
  },
});
