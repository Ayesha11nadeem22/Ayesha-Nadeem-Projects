import React from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
} from "react-native";

const stories = [
  {
    title: "1. Hazrat Adam and the First Sin",
    desc: "Hazrat Adam (A.S) was the first human created by Allah. He lived peacefully in Jannah with Hazrat Hawwa. Allah allowed them to enjoy everything except one forbidden tree. Shaytan tricked them, and they mistakenly ate from it. They immediately regretted their action and prayed for forgiveness. Allah forgave them with mercy and sent them to earth to live and spread goodness. The story teaches responsibility and repentance.",
    img: require("./assets/S1.jpg"),
    routeName: "Story1",
  },
  {
    title: "2. Hazrat Nuh and the Ark",
    desc: "Hazrat Nuh (A.S) warned his people to worship only Allah, but most refused. Allah commanded him to build a great ark. He gathered the believers and pairs of every animal inside the ark. Soon, a massive flood covered the land. Only those inside the ark survived. When the flood ended, they settled safely. This story teaches patience, faith, and trust in Allah’s plan.",
    img: require("./assets/S2.jpg"),
    routeName: "Story2",
  },
  {
    title: "3. Hazrat Ibrahim (A.S) and His Qurbani",
    desc: "Hazrat Ibrahim (A.S) was tested by Allah with a great command to sacrifice his beloved son, Ismail (A.S). He obeyed Allah’s will with complete faith and trust. At the last moment, Allah replaced Ismail with a ram and accepted Ibrahim’s devotion. This story teaches obedience, faith, and complete trust in Allah’s plan.",
    img: require("./assets/S3.jpg"),
    routeName: "Story3",
  },
  {
    title: "4. Hazrat Ishmael and Obedience",
    desc: "Hazrat Ishmael (A.S), the son of Ibrahim, was known for his obedience. When left in the desert with his mother, he remained patient. Through his struggle, Allah blessed them with Zamzam water. Later, he willingly accepted Allah’s command during the sacrifice story. His life teaches patience, courage, and obedience to Allah and parents.",
    img: require("./assets/S4.jpg"),
    routeName: "Story4",
  },
  {
    title: "5. Hazrat Yusuf and His Trials",
    desc: "Hazrat Yusuf (A.S) faced jealousy from his brothers who threw him into a well. He was taken to Egypt and went through many hardships but stayed patient. Allah blessed him with wisdom and made him a leader. He forgave his brothers when he became powerful. His life teaches forgiveness, purity, and patience.",
    img: require("./assets/S5.jpg"),
    routeName: "Story5",
  },
  {
    title: "6. Hazrat Musa and the Sea",
    desc: "Hazrat Musa (A.S) guided his people away from the cruelty of Pharaoh. When chased, they reached the sea. By Allah’s command, the sea parted, creating a safe path for them. Pharaoh drowned when he followed. This miracle shows Allah’s power and the reward of strong faith.",
    img: require("./assets/S6.jpg"),
    routeName: "Story6",
  },
  {
    title: "7. Hazrat Dawud and Goliath",
    desc: "Hazrat Dawud (A.S) was a young boy when he courageously faced the giant warrior Goliath. With faith in Allah, he used his sling to defeat him. People were amazed at his bravery. Allah later blessed him with wisdom, strength, and kingship. His story teaches courage and trust in Allah.",
    img: require("./assets/S7.jpg"),
    routeName: "Story7",
  },
  {
    title: "8. Hazrat Sulaiman and Wisdom",
    desc: "Hazrat Sulaiman (A.S) was known for his exceptional wisdom. Allah gifted him the ability to understand animals and command the wind and jinn. He judged fairly and ruled with kindness. His story teaches leadership, intelligence, and justice.",
    img: require("./assets/S8.jpg"),
    routeName: "Story8",
  },
  {
    title: "9. Hazrat Yunus and the Big Fish",
    desc: "Hazrat Yunus (A.S) left his people after they rejected his message. A great storm struck, and he was swallowed by a huge fish. In darkness, he prayed sincerely to Allah. Allah forgave him and saved him. He returned to guide his people again. His story teaches repentance and patience.",
    img: require("./assets/S9.jpg"),
    routeName: "Story9",
  },
  {
    title: "10. Hazrat Isa and Miracles",
    desc: "Hazrat Isa (A.S) was blessed with the ability to perform miracles by Allah’s permission. He healed the sick, helped the poor, and taught kindness. He spread the message of worshiping one God. His story teaches compassion, mercy, and truth.",
    img: require("./assets/S10.jpg"),
    routeName: "Story10",
  },
];

export default function StoriesScreen({ navigation }) {
  return (
    <ScrollView style={styles.container}>
      <Text style={styles.heading}>🌸 Prophetic Stories</Text>

      {stories.map((story, index) => (
        <View key={index} style={styles.storyBox}>
          <Image source={story.img} style={styles.storyImg} />
          <Text style={styles.storyTitle}>{story.title}</Text>
          <Text style={styles.storyDesc}>{story.desc}</Text>
          <TouchableOpacity
            style={styles.readBtn}
            onPress={() => navigation.navigate(story.routeName)}
          >
            <Text style={styles.btnText}>Let’s Read</Text>
          </TouchableOpacity>
        </View>
      ))}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#ffc1bd",
    paddingTop: 30,
  },
  heading: {
    fontSize: 32,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 20,
    color: "#070707",
  },
  storyBox: {
    backgroundColor: "#ffd6d3",
    borderRadius: 18,
    marginHorizontal: 14,
    marginBottom: 16,
    padding: 10,
    alignItems: "center",
    shadowColor: "#000",
    shadowOpacity: 0.15,
    shadowOffset: { width: 0, height: 4 },
    shadowRadius: 8,
    elevation: 4,
  },
  storyImg: {
    width: "100%",
    height: 130,
    borderRadius: 14,
    resizeMode: "contain",
    marginBottom: 6,
  },
  storyTitle: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#003366",
    textAlign: "center",
    marginBottom: 4,
  },
  storyDesc: {
    fontSize: 15,
    color: "#333",
    lineHeight: 21,
    textAlign: "center",
  },
  readBtn: {
    marginTop: 8,
    paddingVertical: 7,
    paddingHorizontal: 26,
    backgroundColor: "#ffc1bd",
    borderRadius: 22,
  },
  btnText: {
    fontSize: 15,
    fontWeight: "bold",
    color: "#000",
  },
});
