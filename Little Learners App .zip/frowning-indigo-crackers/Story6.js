import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Image,
  TouchableOpacity,
} from "react-native";
import { StatusBar } from "expo-status-bar";

export default function Story6Screen({ navigation }){
  const [lang, setLang] = useState("en");

  const storyText = {
    en: {
      heading1: "The Oppression of Firawn",
      para1:
        "Hazrat Musa (A.S) was sent by Allah to guide the people of Egypt and free the Bani Israel from the cruelty of Firawn. Firawn was arrogant and claimed to be a god. Despite many miracles, he refused to believe.",

      heading2: "Leaving Egypt",
      para2:
        "Allah commanded Hazrat Musa (A.S) to lead the Bani Israel out of Egypt at night. Firawn soon followed them with a huge army.",

      heading3: "Trapped at the Sea",
      para3:
        "The Bani Israel reached the Red Sea and became frightened as Firawn’s army approached. Hazrat Musa (A.S) stayed calm and trusted Allah.",

      heading4: "Miracle: The Sea Splits",
      para4:
        "Allah commanded Hazrat Musa (A.S) to strike the sea with his staff. The sea split into two walls, creating a dry path for the Bani Israel.",

      heading5: "Firawn’s End",
      para5:
        "Firawn followed them into the sea. When the Bani Israel crossed safely, Allah commanded the sea to close, drowning Firawn and his army.",

      para6:
        "This story teaches us that faith, patience, and trust in Allah lead to miracles. Allah always helps His believers.",
    },

    ur: {
      heading1: "فرعون کا ظلم",
      para1:
        "حضرت موسیٰ علیہ السلام کو اللہ نے بنی اسرائیل کو فرعون کے ظلم سے نجات دلانے کے لیے بھیجا۔ فرعون مغرور تھا اور خود کو خدا کہتا تھا۔",

      heading2: "مصر سے ہجرت",
      para2:
        "اللہ کے حکم سے حضرت موسیٰ علیہ السلام بنی اسرائیل کو رات کے وقت مصر سے باہر لے گئے، مگر فرعون نے ایک بڑی فوج کے ساتھ پیچھا کیا۔",

      heading3: "سمندر کے کنارے پھنس جانا",
      para3:
        "بنی اسرائیل سمندر کے کنارے خوفزدہ ہو گئے، مگر حضرت موسیٰ علیہ السلام نے اللہ پر مکمل بھروسہ رکھا۔",

      heading4: "معجزہ: سمندر کا چیر جانا",
      para4:
        "اللہ کے حکم سے حضرت موسیٰ علیہ السلام نے عصا مارا اور سمندر پھٹ گیا، جس سے خشک راستہ بن گیا۔",

      heading5: "فرعون کا انجام",
      para5:
        "فرعون اپنی فوج سمیت سمندر میں داخل ہوا، مگر پانی واپس آ گیا اور سب غرق ہو گئے۔",

      para6:
        "یہ واقعہ ہمیں سکھاتا ہے کہ ایمان اور صبر سے اللہ کی مدد ضرور آتی ہے۔",
    },
  };

  return (
    <ScrollView style={styles.container}>
      {/* Top Image */}
     {/* Top Image */}    
      <Image source={require('./assets/story-of-prophet-musa-as-header.png')} style={styles.topImage} />

      {/* Language Switch */}
      <View style={styles.langBox}>
        <Text style={styles.langText}>READ STORY IN</Text>
        <TouchableOpacity style={styles.langBtn} onPress={() => setLang("en")}>
          <Text>English</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.langBtn} onPress={() => setLang("ur")}>
          <Text>اردو</Text>
        </TouchableOpacity>
      </View>

      {/* Story Content */}
      <Text style={styles.heading}>{storyText[lang].heading1}</Text>
      <Text style={styles.para}>{storyText[lang].para1}</Text>

     {/* Top Image */}    
      <Image source={require('./assets/moses-confronts-pharoah-to-let-his-people-go-GoodSalt-lfwas2231_1.jpg')} style={styles.topImage} />

      <Text style={styles.heading}>{storyText[lang].heading2}</Text>
      <Text style={styles.para}>{storyText[lang].para2}</Text>

     {/* Top Image */}    
      <Image source={require('./assets/sauls-army-GoodSalt-rhpas3413.jpg')} style={styles.topImage} />

      <Text style={styles.heading}>{storyText[lang].heading3}</Text>
      <Text style={styles.para}>{storyText[lang].para3}</Text>

     {/* Top Image */}    
      <Image source={require('./assets/musa (1).jpg')} style={styles.topImage} />

      <Text style={styles.heading}>{storyText[lang].heading4}</Text>
      <Text style={styles.para}>{storyText[lang].para4}</Text>

      <Text style={styles.heading}>{storyText[lang].heading5}</Text>
      <Text style={styles.para}>{storyText[lang].para5}</Text>
      <Text style={styles.para}>{storyText[lang].para6}</Text>

      {/* Back Button */}
       <TouchableOpacity
        style={styles.backBtn}
        onPress={() => navigation.goBack()} // Back to Stories
      >
        <Text style={styles.backText}>← Back to Stories</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "#fff5f3",
    padding: 15,
  },
  topImage: {
    width: "100%",
    height: 240,
    borderRadius: 15,
    marginBottom: 20,
  },
  langBox: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#ffc1bd",
    padding: 10,
    borderRadius: 15,
    marginBottom: 20,
    gap: 10,
  },
  langText: {
    fontWeight: "bold",
  },
  langBtn: {
    backgroundColor: "#fff",
    paddingVertical: 6,
    paddingHorizontal: 15,
    borderRadius: 20,
  },
  heading: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#003366",
    textAlign: "center",
    marginTop: 20,
  },
  para: {
    fontSize: 16,
    textAlign: "center",
    lineHeight: 24,
    marginTop: 10,
  },
  storyImg: {
    width: "80%",
    height: 260,
    borderRadius: 35,
    alignSelf: "center",
    marginVertical: 20,
  },
  backBtn: {
    backgroundColor: "#ffc1bd",
    padding: 15,
    borderRadius: 25,
    marginVertical: 30,
    alignItems: "center",
  },
  backText: {
    fontSize: 18,
    fontWeight: "bold",
  },
});