import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Image,
  TouchableOpacity,
} from "react-native";
import { StatusBar } from "expo-status-bar";

export default function Story2Screen({ navigation }) {
  const [lang, setLang] = useState("en");

  const storyText = {
    en: {
      heading1: "The Prophethood of Hazrat Nuh (A.S)",
      para1:
        "Allah sent Hazrat Nuh (A.S) to guide his people who had turned away from righteousness. He called them to worship Allah alone, but most people rejected and mocked him.",

      heading2: "Building the Ark",
      para2:
        "Allah commanded Hazrat Nuh (A.S) to build a huge ark for a great flood. He followed Allah’s command patiently while people laughed at him.",

      heading3: "The Great Flood",
      para3:
        "When the ark was ready, Allah sent animals in pairs and believers into it. A great flood destroyed the disbelievers, and only those in the ark were saved.",

      heading4: "Lessons from Hazrat Nuh’s Story",
      para4:
        "This story teaches obedience, patience, and strong faith in Allah. Hazrat Nuh (A.S) never gave up calling people to the truth.",

      heading5: "Life After the Flood",
      para5:
        "After the flood, Hazrat Nuh (A.S) and believers rebuilt life on Earth following Allah’s guidance.",
    },

    ur: {
      heading1: "حضرت نوح علیہ السلام کی نبوت",
      para1:
        "اللہ تعالیٰ نے حضرت نوح علیہ السلام کو اپنی قوم کی ہدایت کے لیے بھیجا، مگر اکثر لوگوں نے انکار کیا اور مذاق اڑایا۔",

      heading2: "کشتی کی تعمیر",
      para2:
        "اللہ تعالیٰ نے حضرت نوح علیہ السلام کو ایک بڑی کشتی بنانے کا حکم دیا۔ لوگوں کے مذاق کے باوجود آپ صبر سے کام کرتے رہے۔",

      heading3: "عظیم طوفان",
      para3:
        "کشتی مکمل ہونے پر اللہ نے جانوروں کے جوڑے اور ایمان والوں کو کشتی میں داخل کیا۔ طوفان آیا اور نافرمان تباہ ہو گئے۔",

      heading4: "حضرت نوح علیہ السلام کی کہانی سے سبق",
      para4:
        "یہ کہانی صبر، اطاعت اور اللہ پر مکمل ایمان کا درس دیتی ہے۔",

      heading5: "طوفان کے بعد کی زندگی",
      para5:
        "طوفان کے بعد حضرت نوح علیہ السلام اور مومنوں نے زمین پر نئی زندگی کا آغاز کیا۔",
    },
  };

  const t = storyText[lang];

  return (
    <ScrollView style={styles.container}>
      <StatusBar style="dark" />

      {/* Header Image */}
       {/* Top Image */}    
      <Image source={require('./assets/prophet-nuh-header.png')} style={styles.topImage} />

      {/* Language Switch */}
      <View style={styles.languageBox}>
        <Text style={styles.languageText}>READ STORY IN</Text>

        <TouchableOpacity
          style={styles.langBtn}
          onPress={() => setLang("en")}
        >
          <Text>English</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.langBtn}
          onPress={() => setLang("ur")}
        >
          <Text>اردو</Text>
        </TouchableOpacity>
      </View>

      {/* Story Content */}
      <Text style={styles.heading}>{t.heading1}</Text>
      <Text style={styles.paragraph}>{t.para1}</Text>

      <Text style={styles.heading}>{t.heading2}</Text>
      <Text style={styles.paragraph}>{t.para2}</Text>

 <Image source={require('./assets/noah-the-animals-enter-2-GoodSalt-rhpas0363.jpg')} style={styles.topImage} />


      <Text style={styles.heading}>{t.heading3}</Text>
      <Text style={styles.paragraph}>{t.para3}</Text>

 <Image source={require('./assets/the-great-flood-3-GoodSalt-rhpas0562.jpg')} style={styles.topImage} />


      <Text style={styles.heading}>{t.heading4}</Text>
      <Text style={styles.paragraph}>{t.para4}</Text>

      <Text style={styles.heading}>{t.heading5}</Text>
      <Text style={styles.paragraph}>{t.para5}</Text>

<Image source={require('./assets/god-took-care-of-noah-GoodSalt-lfwas0194.jpg')} style={styles.topImage} />



      <Text style={styles.paragraph}>{t.para6}</Text>
      {/* Back Button */}
       <TouchableOpacity
        style={styles.backBtn}
        onPress={() => navigation.goBack()} // Back to Stories
      >
        <Text style={styles.backText}>← Back to Stories</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "#fff5f3",
    padding: 15,
  },

  topImage: {
    width: "100%",
    height: 200,
    borderRadius: 12,
    marginBottom: 20,
  },

  languageBox: {
    backgroundColor: "#ffc1bd",
    padding: 15,
    borderRadius: 15,
    alignItems: "center",
    marginBottom: 25,
  },

  languageText: {
    fontWeight: "bold",
    marginBottom: 10,
    fontSize: 16,
  },

  langBtn: {
    backgroundColor: "#fff",
    paddingVertical: 8,
    paddingHorizontal: 25,
    borderRadius: 20,
    marginVertical: 5,
  },

  heading: {
    fontSize: 26,
    fontWeight: "bold",
    color: "#003366",
    textAlign: "center",
    marginTop: 20,
  },

  paragraph: {
    fontSize: 18,
    lineHeight: 26,
    textAlign: "center",
    marginTop: 10,
  },

  image: {
    width: "100%",
    height: 180,
    borderRadius: 15,
    marginVertical: 20,
  },

  backBtn: {
    backgroundColor: "#ffc1bd",
    padding: 15,
    borderRadius: 25,
    marginVertical: 30,
    alignItems: "center",
  },

  backText: {
    fontSize: 18,
    fontWeight: "bold",
  },
});