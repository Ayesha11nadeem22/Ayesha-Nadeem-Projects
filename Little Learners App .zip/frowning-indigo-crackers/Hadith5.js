import React from "react";
import {
  View,
  Text,
  StyleSheet,
  Image,
  ScrollView,
  TouchableOpacity,
  Dimensions,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";

const { width } = Dimensions.get("window");

export default function Hadith5Screen({ navigation }) {
  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={{ alignItems: "center", paddingVertical: 20 }}
    >
      {/* Heading */}
      <View style={styles.titleBox}>
        <Text style={styles.title}>Hadith on Sharing</Text>
      </View>

      {/* Card */}
      <LinearGradient
        colors={["#ffffff", "#e9f4ff", "#ffffff", "#d8ebff"]}
        start={[0, 0]}
        end={[1, 1]}
        style={styles.card}
      >
        {/* Text Area */}
        <View style={styles.textArea}>
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Arabic</Text>
            <Text style={[styles.sectionText, styles.arabic]}>
              لَا يُؤْمِنُ أَحَدُكُمْ حَتَّى يُحِبَّ لِأَخِيهِ مَا يُحِبُّ لِنَفْسِهِ
            </Text>
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>English Meaning</Text>
            <Text style={styles.sectionText}>
              “None of you truly believes until he loves for his brother
              what he loves for himself.”
            </Text>
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Urdu Meaning</Text>
            <Text style={styles.sectionText}>
              “تم میں سے کوئی مومن نہیں ہو سکتا جب تک وہ اپنے بھائی کے لئے
              وہی پسند نہ کرے جو اپنے لئے پسند کرتا ہے۔”
            </Text>
          </View>
        </View>

        {/* Image */}
        <View style={styles.imageBox}>
           <Image source={require('./assets/H5.jpg')} style={styles.image} resizeMode="contain" />
        </View>
      </LinearGradient>

      {/* Back Button */}
      <TouchableOpacity
        style={styles.backBtn}
        onPress={() => navigation.goBack()}
      >
        <Text style={styles.backBtnText}>← Back To Hadiths</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#ffdde4",
  },
  titleBox: {
    marginBottom: 20,
    alignItems: "center",
  },
  title: {
    backgroundColor: "white",
    paddingVertical: 12,
    paddingHorizontal: 25,
    borderRadius: 22,
    color: "#148dd3",
    fontSize: 28,
    fontWeight: "bold",
    borderWidth: 3,
    borderColor: "#148dd3",
    textAlign: "center",
  },
  card: {
    flexDirection: width > 768 ? "row" : "column",
    width: width - 40,
    maxWidth: 950,
    borderRadius: 22,
    padding: 25,
    borderWidth: 3,
    borderColor: "#e6f1ff",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.15,
    shadowRadius: 25,
    elevation: 5,
    gap: 25,
    alignItems: "center",
  },
  textArea: {
    flex: 1,
  },
  section: {
    marginBottom: 18,
  },
  sectionTitle: {
    fontSize: 22,
    color: "#4c80ce",
    marginBottom: 6,
    fontWeight: "bold",
  },
  sectionText: {
    fontSize: 17,
    lineHeight: 26,
    backgroundColor: "#ffffff",
    padding: 12,
    borderRadius: 15,
    borderWidth: 2,
    borderColor: "#cde6ff",
    color: "#4a4a4a",
  },
  arabic: {
    fontSize: 23,
    fontWeight: "bold",
    textAlign: "right",
    borderWidth: 3,
    borderStyle: "dotted",
    borderColor: "#a9d4ff",
    backgroundColor: "#f2f7ff",
  },
  imageBox: {
    flex: 1,
    width: "100%",
    maxWidth: 300,
    alignItems: "center",
    justifyContent: "center",
    marginTop: width > 768 ? 0 : 25,
  },
  image: {
    width: "100%",
    maxWidth: 300,
    height: 220,
    borderRadius: 15,
  },
  backBtn: {
    marginTop: 25,
    backgroundColor: "#7b9eff",
    paddingVertical: 10,
    paddingHorizontal: 18,
    borderRadius: 15,
    elevation: 5,
  },
  backBtnText: {
    color: "white",
    fontWeight: "bold",
    fontSize: 16,
  },
});
