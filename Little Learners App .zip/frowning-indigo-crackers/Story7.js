import React, { useState } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  Image, 
  ScrollView, 
  TouchableOpacity 
} from 'react-native';
import { StatusBar } from "expo-status-bar";

export default function Story7Screen({ navigation }){

  const [lang, setLang] = useState("en");

  const storyText = {
    en: {
      heading1: "The Rise of a Young Shepherd",
      para1: "Hazrat Dawood (A.S) was a young shepherd chosen by Allah for a great mission. He belonged to the army of King Talut and trusted Allah completely.",
      heading2: "Goliath’s Challenge",
      para2: "Goliath was a giant warrior who challenged King Talut's army daily. No one dared to fight him due to fear.",
      heading3: "Dawood (A.S) Accepts the Battle",
      para3: "Despite being young, Dawood (A.S) trusted Allah and accepted the challenge using only a sling and stones.",
      heading4: "The Battle with Goliath",
      para4: "Dawood (A.S) struck Goliath with a stone using his sling. Goliath fell defeated by Allah’s help.",
      heading5: "Victory and Allah’s Gift",
      para5: "Allah made Dawood (A.S) a prophet and king. He ruled with justice and wisdom.",
      para6: "This story teaches us that strong faith in Allah brings success."
    },

    ur: {
      heading1: "ایک نوجوان چرواہے کا ابھار",
      para1: "حضرت داؤدؑ ایک نوجوان چرواہے تھے جنہیں اللہ نے ایک عظیم مقصد کے لیے منتخب کیا۔",
      heading2: "جالوت کا چیلنج",
      para2: "جالوت ایک طاقتور جنگجو تھا جس سے پوری فوج خوفزدہ تھی۔",
      heading3: "حضرت داؤدؑ کا مقابلہ قبول کرنا",
      para3: "حضرت داؤدؑ نے اللہ پر بھروسہ کرتے ہوئے مقابلہ قبول کیا۔",
      heading4: "جالوت سے مقابلہ",
      para4: "حضرت داؤدؑ نے گوپھن سے پتھر مارا اور جالوت شکست کھا گیا۔",
      heading5: "فتح اور اللہ کا انعام",
      para5: "اللہ نے حضرت داؤدؑ کو نبی اور بادشاہ بنایا۔",
      para6: "یہ کہانی ہمیں ایمان کی طاقت سکھاتی ہے۔"
    }
  };

  const t = storyText[lang];

  return (
    <ScrollView style={styles.container}>

      {/* Top Image */}
     {/* Top Image */}    
      <Image source={require('./assets/the-story-of-prophet-dawud-as.jpg')} style={styles.topImage} />

      {/* Language Switch */}
      <View style={styles.languageBox}>
        <Text style={styles.langText}>READ STORY IN</Text>

        <TouchableOpacity onPress={() => setLang("en")} style={styles.langBtn}>
          <Text>English</Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={() => setLang("ur")} style={styles.langBtn}>
          <Text>اردو</Text>
        </TouchableOpacity>
      </View>

      {/* Story Content */}
      <Text style={styles.heading}>{t.heading1}</Text>
      <Text style={styles.para}>{t.para1}</Text>

      <Text style={styles.heading}>{t.heading2}</Text>
      <Text style={styles.para}>{t.para2}</Text>

      <Text style={styles.heading}>{t.heading3}</Text>
      <Text style={styles.para}>{t.para3}</Text>

      <Text style={styles.heading}>{t.heading4}</Text>
      <Text style={styles.para}>{t.para4}</Text>

      <Text style={styles.heading}>{t.heading5}</Text>
      <Text style={styles.para}>{t.para5}</Text>

      <Text style={styles.para}>{t.para6}</Text>

 {/* Back Button */}
       <TouchableOpacity
        style={styles.backBtn}
        onPress={() => navigation.goBack()} // Back to Stories
      >
        <Text style={styles.backText}>← Back to Stories</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#fff5f3',
    padding: 15
  },
  topImage: {
    width: '100%',
    height: 200,
    borderRadius: 15,
    marginBottom: 20
  },
  languageBox: {
    backgroundColor: '#ffc1bd',
    padding: 15,
    borderRadius: 15,
    alignItems: 'center',
    marginBottom: 20
  },
  langText: {
    fontWeight: 'bold',
    marginBottom: 10
  },
  langBtn: {
    backgroundColor: '#fff',
    padding: 10,
    borderRadius: 20,
    marginVertical: 5,
    width: 120,
    alignItems: 'center'
  },
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#003366',
    textAlign: 'center',
    marginTop: 20
  },
  para: {
    fontSize: 16,
    textAlign: 'center',
    marginTop: 10,
    lineHeight: 24
  },
  backBtn: {
    backgroundColor: '#ffc1bd',
    padding: 15,
    borderRadius: 25,
    alignItems: 'center',
    marginVertical: 30
  },
backText: {
  fontSize: 18,
  fontWeight: "bold",
},
});