import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  ScrollView,
  TouchableOpacity
} from 'react-native';
import { StatusBar } from "expo-status-bar";

export default function Story9Screen({ navigation }) {

  const [lang, setLang] = useState("en");

  const storyText = {
    en: {
      heading1: "The People Who Rejected Hazrat Yunus (A.S)",
      para1:
        "Hazrat Yunus (A.S) was sent by Allah to guide a people who had turned away from faith. Despite repeated warnings, they refused to worship Allah. Feeling distressed, he left the city without Allah’s permission.",

      heading2: "The Storm at Sea",
      para2:
        "Hazrat Yunus (A.S) boarded a ship when a violent storm arose. The ship was in danger of sinking, and lots were drawn. His name was selected, and he was cast into the sea.",

      heading3: "Swallowed by the Big Fish",
      para3:
        "Allah commanded a huge fish to swallow Hazrat Yunus (A.S) without harming him. In the darkness, he realized his mistake and sincerely asked Allah for forgiveness.",

      heading4: "The Famous Dua",
      para4:
        "Hazrat Yunus (A.S) recited the famous dua: “La ilaha illa Anta, Subhanaka, inni kuntu minaz-zalimeen.” Allah accepted his prayer and ordered the fish to release him.",

      heading5: "Return and Guidance",
      para5:
        "Hazrat Yunus (A.S) returned to his people, who accepted Allah’s message. His story teaches patience, repentance, and Allah’s mercy."
    },

    ur: {
      heading1: "حضرت یونس علیہ السلام کی قوم کی نافرمانی",
      para1:
        "حضرت یونس علیہ السلام کو اللہ نے ایک ایسی قوم کی طرف بھیجا جو ایمان سے منہ موڑ چکی تھی۔ بار بار سمجھانے کے باوجود وہ باز نہ آئے، جس پر حضرت یونس علیہ السلام رنجیدہ ہو کر شہر چھوڑ گئے۔",

      heading2: "سمندر میں طوفان",
      para2:
        "حضرت یونس علیہ السلام جہاز پر سوار ہوئے مگر شدید طوفان آ گیا۔ قرعہ اندازی میں ان کا نام نکلا اور انہیں سمندر میں اتار دیا گیا۔",

      heading3: "بڑی مچھلی کے پیٹ میں",
      para3:
        "اللہ کے حکم سے ایک بڑی مچھلی نے حضرت یونس علیہ السلام کو بغیر نقصان کے نگل لیا۔ اندھیروں میں انہوں نے توبہ کی اور اللہ سے معافی مانگی۔",

      heading4: "مشہور دعا",
      para4:
        "حضرت یونس علیہ السلام نے یہ دعا پڑھی: “لَا اِلٰہَ اِلَّا اَنْتَ سُبْحَانَکَ اِنِّیْ کُنْتُ مِنَ الظّٰلِمِیْن”۔ اللہ نے ان کی دعا قبول فرما لی۔",

      heading5: "واپسی اور ہدایت",
      para5:
        "حضرت یونس علیہ السلام واپس اپنی قوم کے پاس آئے اور قوم نے اللہ کی ہدایت قبول کر لی۔ یہ واقعہ صبر اور توبہ کا درس دیتا ہے۔"
    }
  };

  const t = storyText[lang];

  return (
    <ScrollView style={styles.container}>

      {/* Top Image */}
     {/* Top Image */}    
      <Image source={require('./assets/story-of-prophet-yunus.webp')} style={styles.topImage} />

      {/* Language Switch */}
      <View style={styles.languageBox}>
        <Text style={styles.langText}>READ STORY IN</Text>

        <TouchableOpacity
          style={styles.langBtn}
          onPress={() => setLang("en")}
        >
          <Text>English</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.langBtn}
          onPress={() => setLang("ur")}
        >
          <Text>اردو</Text>
        </TouchableOpacity>
      </View>

      {/* Story Content */}
      <Text style={styles.heading}>{t.heading1}</Text>
      <Text style={styles.para}>{t.para1}</Text>

      <Text style={styles.heading}>{t.heading2}</Text>
      <Text style={styles.para}>{t.para2}</Text>

     {/* Top Image */}    
      <Image source={require('./assets/yunus (1).jpg')} style={styles.topImage} />

      <Text style={styles.heading}>{t.heading3}</Text>
      <Text style={styles.para}>{t.para3}</Text>

     {/* Top Image */}    
      <Image source={require('./assets/yunus (2).jpg')} style={styles.topImage} />

      <Text style={styles.heading}>{t.heading4}</Text>
      <Text style={styles.para}>{t.para4}</Text>

      <Text style={styles.heading}>{t.heading5}</Text>
      <Text style={styles.para}>{t.para5}</Text>

     {/* Top Image */}    
      <Image source={require('./assets/yunus (3).jpg')} style={styles.topImage} />

     
{/* Back Button */}
       <TouchableOpacity
        style={styles.backBtn}
        onPress={() => navigation.goBack()} // Back to Stories
      >
        <Text style={styles.backText}>← Back to Stories</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#fff5f3',
    padding: 15
  },
  topImage: {
    width: '100%',
    height: 200,
    borderRadius: 15,
    marginBottom: 20
  },
  languageBox: {
    backgroundColor: '#ffc1bd',
    padding: 15,
    borderRadius: 15,
    alignItems: 'center',
    marginBottom: 20
  },
  langText: {
    fontWeight: 'bold',
    marginBottom: 10
  },
  langBtn: {
    backgroundColor: '#fff',
    padding: 10,
    borderRadius: 20,
    marginVertical: 5,
    width: 140,
    alignItems: 'center'
  },
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#003366',
    textAlign: 'center',
    marginTop: 20
  },
  para: {
    fontSize: 16,
    textAlign: 'center',
    marginTop: 10,
    lineHeight: 24
  },
  storyImage: {
    width: '100%',
    height: 180,
    borderRadius: 15,
    marginVertical: 15
  },
  backBtn: {
    backgroundColor: '#ffc1bd',
    padding: 15,
    borderRadius: 25,
    alignItems: 'center',
    marginVertical: 30
  },
backText: {
  fontSize: 18,
  fontWeight: "bold",
},
});