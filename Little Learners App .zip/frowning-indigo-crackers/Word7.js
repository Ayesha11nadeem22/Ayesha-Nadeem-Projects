import React from "react";
import { View, Text, StyleSheet, Image, TouchableOpacity, ScrollView, Dimensions } from "react-native";

const { width, height } = Dimensions.get("window");

export default function Word7Screen({ navigation }) {
  return (
    <View style={styles.screen}>
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <View style={styles.card}>
          {/* Image at top */}
          <Image
            source={require("./assets/shahada.jpg")}
            style={styles.image}
            resizeMode="cover"
          />

          {/* Text content below image */}
          <View style={styles.textContent}>
            <Text style={styles.heading}>Word in Arabic</Text>
            <View style={styles.arabicWord}>
              <Text style={styles.arabicText}>الشهادة</Text>
            </View>

            <Text style={styles.heading}>English Translation</Text>
            <Text style={styles.translation}>Testimony of faith</Text>

            <Text style={styles.heading}>Urdu Translation</Text>
            <Text style={styles.translationUrdu}>کلمہ – ایمان کا اقرار</Text>

            <TouchableOpacity
              style={styles.button}
              onPress={() => navigation.goBack()}
            >
              <Text style={styles.buttonText}>← Back to Islamic Words</Text>
            </TouchableOpacity>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: "#5a5400",
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
  },
  card: {
    width: width - 20,
    height: height - 40, // full screen minus padding
    backgroundColor: "#d8c98c",
    borderRadius: 28,
    shadowColor: "#000",
    shadowOpacity: 0.3,
    shadowRadius: 15,
    shadowOffset: { width: 0, height: 5 },
    overflow: "hidden",
    alignItems: "center",
  },
  image: {
    width: "100%",
    height: "45%", // image at top
  },
  textContent: {
    flex: 1,
    padding: 20,
    alignItems: "center",
  },
  heading: {
    fontSize: 24,
    fontWeight: "bold",
    marginTop: 10,
    marginBottom: 5,
    color: "#2f2208",
    textAlign: "center",
  },
  arabicWord: {
    backgroundColor: "#c47543",
    paddingVertical: 12,
    paddingHorizontal: 30,
    borderRadius: 12,
    marginBottom: 20,
    minWidth: 240,
    alignItems: "center",
  },
  arabicText: {
    fontSize: 40,
    fontWeight: "bold",
    color: "black",
    textAlign: "center",
  },
  translation: {
    fontSize: 20,
    marginBottom: 15,
    textAlign: "center",
    color: "#2f2208",
  },
  translationUrdu: {
    fontSize: 18,
    marginBottom: 20,
    textAlign: "center",
    color: "#2f2208",
  },
  button: {
    backgroundColor: "#5a5400",
    paddingVertical: 14,
    paddingHorizontal: 32,
    borderRadius: 22,
    elevation: 5,
  },
  buttonText: {
    color: "white",
    fontSize: 18,
    fontWeight: "bold",
  },
});
