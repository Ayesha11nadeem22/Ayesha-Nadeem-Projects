import React from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';

export default function Dua7Screen({ navigation }) {
  return (
    <ScrollView contentContainerStyle={styles.container}>
      {/* Title */}
      <View style={styles.titleBox}>
        <Text style={styles.title}>Dua for Entering Home</Text>
      </View>

      {/* Card Container */}
      <View style={styles.cardContainer}>
        {/* Left Box */}
        <View style={styles.cardText}>
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Arabic</Text>
            <Text style={styles.arabic}>
              بِسْمِ اللَّهِ وَلَجْنَا، وَبِسْمِ اللَّهِ خَرَجْنَا، وَعَلَى اللَّهِ رَبِّنَا تَوَكَّلْنَا
            </Text>
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>English Meaning</Text>
            <Text style={styles.sectionText}>
              In the name of Allah we enter, in the name of Allah we leave,
              and upon our Lord we place our trust.
            </Text>
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Urdu Meaning</Text>
            <Text style={styles.sectionText}>
              اللہ کے نام سے ہم داخل ہوئے، اور اللہ کے نام سے ہم نکلے،
              اور ہم نے اپنے رب اللہ پر بھروسا کیا۔
            </Text>
          </View>
        </View>

        {/* Right Box */}
        <View style={styles.cardImage}>
           <Image source={require('./assets/D7.jpg')} style={styles.image} resizeMode="contain" />
        </View>
      </View>

      <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
  <Text style={styles.backBtnText}>← Back to Duas</Text>
</TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: '#ffdde4', // simplified gradient
    alignItems: 'center',
    padding: 20,
  },
  titleBox: {
    marginBottom: 20,
  },
  title: {
    fontSize: 25,
    color: '#5f0177',
    backgroundColor: '#d8a4bb',
    paddingVertical: 20,
    paddingHorizontal: 40,
    borderRadius: 30,
    borderWidth: 3,
    borderColor: '#ffffff50',
    textTransform: 'uppercase',
    letterSpacing: 2,
    fontWeight: '700',
    textAlign: 'center',
    elevation: 5,
  },
  cardContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    gap: 20,
    maxWidth: 1000,
  },
  cardText: {
    flex: 1,
    minWidth: 300,
    backgroundColor: '#f5f7ff',
    borderRadius: 25,
    borderWidth: 2,
    borderColor: '#d0d8ff',
    padding: 20,
    marginBottom: 20,
  },
  section: {
    backgroundColor: '#f0f4ff',
    borderRadius: 20,
    padding: 15,
    marginBottom: 15,
    borderLeftWidth: 6,
    borderLeftColor: '#8c6ff7',
    elevation: 3,
  },
  sectionTitle: {
    fontSize: 20,
    color: '#8c6ff7',
    marginBottom: 10,
  },
  sectionText: {
    fontSize: 17,
    color: '#4a4a4a',
    lineHeight: 24,
    textAlign: 'justify',
  },
  arabic: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'right',
    backgroundColor: '#e3eaff',
    padding: 10,
    borderRadius: 10,
  },
  cardImage: {
    width: 350,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 15,
  },
  image: {
    width: '100%',
    height: 200,
    borderRadius: 25,
    borderWidth: 2,
    borderColor: '#cde6ff',
  },
  backBtn: {
    marginTop: 25,
    backgroundColor: '#5b1888',
    paddingVertical: 10,
    paddingHorizontal: 18,
    borderRadius: 15,
    elevation: 4,
  },
  backBtnText: {
    color: 'white',
    fontWeight: 'bold',
  },
});
