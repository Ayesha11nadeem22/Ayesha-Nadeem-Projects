import React, { useEffect, useRef } from 'react';
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  TouchableOpacity,
  Animated,
  Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

const { width } = Dimensions.get('window');

const Bubble = ({ left, size, duration }) => {
  const translateY = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.loop(
      Animated.timing(translateY, {
        toValue: -260,
        duration: duration,
        useNativeDriver: true,
      })
    ).start();
  }, []);

  return (
    <Animated.View
      style={[
        styles.bubble,
        {
          width: size,
          height: size,
          left: left,
          transform: [{ translateY }],
        },
      ]}
    />
  );
};

const QuizBox = ({ title, desc, onPress }) => {
  return (
    <View style={styles.quizBox}>
      <Text style={styles.quizTitle}>{title}</Text>
      <Text style={styles.quizDesc}>{desc}</Text>

      <TouchableOpacity onPress={onPress} activeOpacity={0.8}>
        <LinearGradient
          colors={['#ff8a65', '#ffb74d']}
          style={styles.button}
        >
          <Text style={styles.buttonText}>Let’s Do</Text>
        </LinearGradient>
      </TouchableOpacity>

      {/* bubbles */}
      <Bubble left="10%" size={8} duration={4000} />
      <Bubble left="25%" size={12} duration={6000} />
      <Bubble left="40%" size={10} duration={5000} />
      <Bubble left="60%" size={14} duration={7000} />
      <Bubble left="80%" size={9} duration={4500} />
    </View>
  );
};

export default function Quizes({ navigation }) {
  return (
    <LinearGradient
      colors={['#f7a8ba', '#caa867']}
      style={styles.container}
    >
      <Text style={styles.heading}>🌸 Quiz Section 🌸</Text>

      <ScrollView contentContainerStyle={styles.quizContainer}>
        <QuizBox
          title="🕌 Islamic Quiz"
          desc="Test your knowledge about Islam"
          onPress={() => navigation.navigate('Islam')}
        />

        <QuizBox
          title="🔬 Science Quiz"
          desc="Challenge your brain with science"
          onPress={() => navigation.navigate('Science')}
        />

        <QuizBox
          title="🌍 GK Quiz"
          desc="General knowledge for kids"
          onPress={() => navigation.navigate('GK')}
        />

        <QuizBox
          title="📚 English Quiz"
          desc="How strong is your English?"
          onPress={() => navigation.navigate('English')}
        />

        <QuizBox
          title="➗ Math Quiz"
          desc="Solve different problems"
          onPress={() => navigation.navigate('Math')}
        />

        <QuizBox
          title="📜 Pak History Quiz"
          desc="Explore the past"
          onPress={() => navigation.navigate('History')}
        />
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  heading: {
    textAlign: 'center',
    fontSize: 28,
    fontWeight: 'bold',
    marginTop: 30,
    marginBottom: 20,
  },
  quizContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    paddingBottom: 40,
  },
  quizBox: {
    width: width * 0.85,
    backgroundColor: '#fcd5d5',
    borderRadius: 25,
    borderWidth: 4,
    borderColor: '#7c034a',
    padding: 20,
    marginVertical: 12,
    alignItems: 'center',
    overflow: 'hidden',
    elevation: 8,
  },
  quizTitle: {
    fontSize: 22,
    color: '#7c034a',
    marginBottom: 5,
  },
  quizDesc: {
    fontSize: 18,
    textAlign: 'center',
  },
  button: {
    marginTop: 15,
    paddingVertical: 12,
    paddingHorizontal: 35,
    borderRadius: 30,
  },
  buttonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
  },
  bubble: {
    position: 'absolute',
    bottom: -30,
    backgroundColor: 'rgba(255,105,180,0.7)',
    borderRadius: 50,
  },
});
