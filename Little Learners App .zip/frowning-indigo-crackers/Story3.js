import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Image,
  TouchableOpacity,
} from "react-native";
import { StatusBar } from "expo-status-bar";

export default function Story3Screen({ navigation })  {
  const [lang, setLang] = useState("en");

  const storyText = {
    en: {
      heading1: "Hazrat Ibrahim (A.S) and His Qurbani",
      para1:
        "Hazrat Ibrahim (A.S) was tested by Allah with a command to sacrifice his beloved son, Ismail (A.S). With complete faith, he prepared to obey Allah’s command. At the last moment, Allah replaced Ismail with a ram and accepted Ibrahim’s devotion.",
      heading2: "The Command of Allah",
      para2:
        "Allah wanted to test the devotion of Hazrat Ibrahim (A.S) and his son Ismail (A.S). Both submitted to Allah’s will with patience and obedience.",
      heading3: "The Sacrifice and Mercy",
      para3:
        "When Hazrat Ibrahim (A.S) raised the knife, Allah replaced Ismail (A.S) with a ram, showing His mercy and acceptance.",
      heading4: "Lessons for Humanity",
      para4:
        "This story teaches faith, patience, and obedience to Allah. It is remembered every year during Eid-ul-Adha.",
    },
    ur: {
      heading1: "حضرت ابراہیم علیہ السلام اور قربانی",
      para1:
        "حضرت ابراہیم علیہ السلام کو اللہ کی طرف سے اپنے بیٹے حضرت اسماعیل علیہ السلام کی قربانی کا حکم ملا۔ انہوں نے مکمل ایمان کے ساتھ اللہ کے حکم کی تعمیل کی۔",
      heading2: "اللہ کا حکم",
      para2:
        "اللہ تعالیٰ حضرت ابراہیم علیہ السلام اور ان کے بیٹے کے ایمان کی آزمائش کرنا چاہتے تھے۔ دونوں نے صبر اور اطاعت کا مظاہرہ کیا۔",
      heading3: "قربانی اور رحمت",
      para3:
        "اللہ تعالیٰ نے حضرت اسماعیل علیہ السلام کی جگہ ایک دنبہ بھیج دیا، جو اللہ کی رحمت کی علامت ہے۔",
      heading4: "انسانیت کے لیے سبق",
      para4:
        "یہ واقعہ ہمیں ایمان، صبر اور اللہ کے احکامات کی اطاعت سکھاتا ہے۔",
    },
  };

  return (
    <ScrollView style={styles.container}>
      {/* Top Image */}
       <Image source={require('./assets/Feature-Img-MQ-copyC-1024x597.webp')} style={styles.topImage} />

      {/* Language Switch */}
      <View style={styles.langBox}>
        <Text style={styles.langText}>READ STORY IN</Text>
        <TouchableOpacity
          style={styles.langBtn}
          onPress={() => setLang("en")}
        >
          <Text>English</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.langBtn}
          onPress={() => setLang("ur")}
        >
          <Text>اردو</Text>
        </TouchableOpacity>
      </View>

      {/* Story Content */}
      <Text style={styles.heading}>{storyText[lang].heading1}</Text>
      <Text style={styles.para}>{storyText[lang].para1}</Text>

      <Image source={require('./assets/abraham-and-isaac-find-the-ram-GoodSalt-dmtag0161.jpg')} style={styles.topImage} />

      <Text style={styles.heading}>{storyText[lang].heading2}</Text>
      <Text style={styles.para}>{storyText[lang].para2}</Text>

      <Text style={styles.heading}>{storyText[lang].heading3}</Text>
      <Text style={styles.para}>{storyText[lang].para3}</Text>

      <Text style={styles.heading}>{storyText[lang].heading4}</Text>
      <Text style={styles.para}>{storyText[lang].para4}</Text>

      {/* Back Button */}
       <TouchableOpacity
        style={styles.backBtn}
        onPress={() => navigation.goBack()} // Back to Stories
      >
        <Text style={styles.backText}>← Back to Stories</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "#fff5f3",
    padding: 15,
  },
  topImage: {
    width: "100%",
    height: 220,
    borderRadius: 15,
    marginBottom: 20,
  },
  langBox: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#ffc1bd",
    padding: 10,
    borderRadius: 15,
    marginBottom: 20,
    gap: 10,
  },
  langText: {
    fontWeight: "bold",
  },
  langBtn: {
    backgroundColor: "#fff",
    paddingVertical: 6,
    paddingHorizontal: 15,
    borderRadius: 20,
  },
  heading: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#003366",
    textAlign: "center",
    marginTop: 20,
  },
  para: {
    fontSize: 16,
    textAlign: "center",
    lineHeight: 24,
    marginTop: 10,
  },
  image: {
    width: "100%",
    height: 200,
    borderRadius: 15,
    marginVertical: 15,
  },
  backBtn: {
    backgroundColor: "#ffc1bd",
    padding: 15,
    borderRadius: 25,
    marginVertical: 30,
    alignItems: "center",
  },
  backText: {
    fontSize: 18,
    fontWeight: "bold",
  },
});