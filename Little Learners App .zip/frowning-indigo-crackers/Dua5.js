import React from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';

export default function Dua5Screen({ navigation }) {
  return (
    <ScrollView contentContainerStyle={styles.container}>
      {/* Title */}
      <View style={styles.titleBox}>
        <Text style={styles.title}>Dua Before Study</Text>
      </View>

      {/* Card Container */}
      <View style={styles.cardContainer}>
        {/* Left Box */}
        <View style={styles.cardText}>
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Arabic</Text>
            <Text style={styles.arabic}>
              اللّهُمَّ انْفَعْنِي بِمَا عَلَّمْتَنِي وَعَلِّمْنِي مَا يَنْفَعُنِي
            </Text>
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>English Meaning</Text>
            <Text style={styles.sectionText}>
              O Allah! Benefit me with what You have taught me and teach me that which will benefit me.
            </Text>
          </View>

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Urdu Meaning</Text>
            <Text style={styles.sectionText}>
              اے اللہ! جو کچھ تُو نے مجھے سکھایا ہے اس سے مجھے فائدہ دے اور وہ سکھا جس سے مجھے فائدہ ہو۔
            </Text>
          </View>
        </View>

        {/* Right Box */}
        <View style={styles.cardImage}>
           <Image source={require('./assets/D5.jpg')} style={styles.image} resizeMode="contain" />
        </View>
      </View>

      <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
  <Text style={styles.backBtnText}>← Back to Duas</Text>
</TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    backgroundColor: '#ffdde4', // simplified gradient
    alignItems: 'center',
    padding: 20,
  },
  titleBox: {
    marginBottom: 20,
  },
  title: {
    fontSize: 25,
    color: '#5f0177',
    backgroundColor: '#d8a4bb',
    paddingVertical: 20,
    paddingHorizontal: 40,
    borderRadius: 30,
    borderWidth: 3,
    borderColor: '#ffffff50',
    textTransform: 'uppercase',
    letterSpacing: 2,
    fontWeight: '700',
    textAlign: 'center',
    elevation: 5,
  },
  cardContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    gap: 20,
    maxWidth: 1000,
  },
  cardText: {
    flex: 1,
    minWidth: 300,
    backgroundColor: '#f5f7ff',
    borderRadius: 25,
    borderWidth: 2,
    borderColor: '#d0d8ff',
    padding: 20,
    marginBottom: 20,
  },
  section: {
    backgroundColor: '#f0f4ff',
    borderRadius: 20,
    padding: 15,
    marginBottom: 15,
    borderLeftWidth: 6,
    borderLeftColor: '#8c6ff7',
    elevation: 3,
  },
  sectionTitle: {
    fontSize: 20,
    color: '#8c6ff7',
    marginBottom: 10,
  },
  sectionText: {
    fontSize: 17,
    color: '#4a4a4a',
    lineHeight: 24,
    textAlign: 'justify',
  },
  arabic: {
    fontSize: 23,
    fontWeight: 'bold',
    textAlign: 'right',
    backgroundColor: '#e3eaff',
    padding: 10,
    borderRadius: 10,
  },
  cardImage: {
    width: 350,
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 15,
  },
  image: {
    width: '100%',
    height: 200,
    borderRadius: 25,
    borderWidth: 2,
    borderColor: '#cde6ff',
  },
  backBtn: {
    marginTop: 25,
    backgroundColor: '#5b1888',
    paddingVertical: 10,
    paddingHorizontal: 18,
    borderRadius: 15,
    elevation: 4,
  },
  backBtnText: {
    color: 'white',
    fontWeight: 'bold',
  },
});
