import React, { useRef, useEffect } from "react";
import { View, Text, StyleSheet, ScrollView, Dimensions, TouchableOpacity, Animated } from "react-native";

const { width, height } = Dimensions.get("window");

export default function Words({ navigation }) {
  const floatAnims = useRef(Array(10).fill().map(() => new Animated.Value(0))).current;
  const bubbleAnims = useRef(Array(20).fill().map(() => new Animated.Value(Math.random() * height))).current;

  useEffect(() => {
    // Floating animation for cards
    floatAnims.forEach((anim) => {
      Animated.loop(
        Animated.sequence([
          Animated.timing(anim, { toValue: -10, duration: 3000, useNativeDriver: true }),
          Animated.timing(anim, { toValue: 0, duration: 3000, useNativeDriver: true }),
        ])
      ).start();
    });

    // Bubbles floating animation
    bubbleAnims.forEach((anim) => {
      const animateBubble = () => {
        anim.setValue(height + Math.random() * 100);
        Animated.timing(anim, {
          toValue: -50,
          duration: 5000 + Math.random() * 5000,
          useNativeDriver: true,
        }).start(() => animateBubble());
      };
      animateBubble();
    });
  }, []);

  const words = [
    { id: 1, word: "Word 1", desc: "Word for Greeting" },
    { id: 2, word: "Word 2", desc: "Word for Prayer" },
    { id: 3, word: "Word 3", desc: "Word for Quran" },
    { id: 4, word: "Word 4", desc: "Word for Fast" },
    { id: 5, word: "Word 5", desc: "Word for Charity" },
    { id: 6, word: "Word 6", desc: "Word for Pilgrimage" },
    { id: 7, word: "Word 7", desc: "Word for Testimony of Faith" },
    { id: 8, word: "Word 8", desc: "Word for Sayings of Prophet" },
    { id: 9, word: "Word 9", desc: "Word for Gratitude" },
    { id: 10, word: "Word 10", desc: "Word for Reliance on Allah" },
  ];

  const bubbleColors = ["rgba(255,255,255,0.3)", "rgba(200,200,255,0.4)", "rgba(255,200,200,0.3)"];

  return (
    <View style={styles.screen}>
      {/* Bubbles */}
      {bubbleAnims.map((anim, index) => {
        const size = 10 + Math.random() * 20;
        const left = Math.random() * width;
        const bg = bubbleColors[Math.floor(Math.random() * bubbleColors.length)];
        return (
          <Animated.View
            key={index}
            style={{
              position: "absolute",
              width: size,
              height: size,
              borderRadius: size / 2,
              backgroundColor: bg,
              left,
              transform: [{ translateY: anim }],
            }}
          />
        );
      })}

      <ScrollView contentContainerStyle={styles.container}>
        <Text style={styles.heading}>🌸 Islamic Words 🌸</Text>
        {words.map((item, index) => (
          <Animated.View
            key={item.id}
            style={[styles.card, { transform: [{ translateY: floatAnims[index] }] }]}
          >
            <Text style={styles.word}>{item.word}</Text>
            <Text style={styles.desc}>{item.desc}</Text>
           <TouchableOpacity
  style={styles.button}
  onPress={() => navigation.navigate(`Word${item.id}`)}
>
  <Text style={{ color: "white", fontWeight: "bold" }}>Read Word</Text>
</TouchableOpacity>


          </Animated.View>
        ))}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: "#5a5400" },
  container: {
    padding: 20,
    alignItems: "center",
    paddingBottom: 50,
  },
  heading: {
    fontSize: 28,
    color: "white",
    marginBottom: 30,
    fontWeight: "bold",
    textAlign: "center",
  },
  card: {
    width: width - 40, // Full width minus padding
    backgroundColor: "#d8c98c",
    borderRadius: 28,
    paddingVertical: 40,
    paddingHorizontal: 20,
    marginVertical: 10,
    alignItems: "center",
    shadowColor: "#000",
    shadowOpacity: 0.3,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 5 },
  },
  word: {
    fontSize: 24,
    fontWeight: "600",
    marginBottom: 10,
    textAlign: "center",
  },
  desc: {
    fontSize: 18,
    color: "#2f2208",
    marginBottom: 15,
    textAlign: "center",
  },
  button: {
    backgroundColor: "#5a5400",
    paddingVertical: 12,
    paddingHorizontal: 25,
    borderRadius: 22,
  },
});
