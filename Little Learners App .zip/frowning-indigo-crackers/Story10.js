import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  Image,
  TouchableOpacity
} from 'react-native';
import { StatusBar } from "expo-status-bar";

export default function Story10Screen({ navigation }) {
  const [lang, setLang] = useState('en');

  const storyText = {
    en: {
      heading1: "Birth and Early Life of Hazrat Isa (A.S)",
      para1: "Hazrat Isa (A.S) was born miraculously to Hazrat Maryam (A.S) without a father, by the command of Allah. From an early age, he showed great wisdom and devotion to Allah.",
      heading2: "Preaching to the People",
      para2: "Hazrat Isa (A.S) invited people to worship Allah alone and follow righteous paths. He performed miracles by Allah’s permission, such as healing the sick and giving sight to the blind.",
      heading3: "Miracles by the Will of Allah",
      para3: "His miracles include giving life to the dead, creating birds from clay, and providing food to the needy, all by Allah’s command.",
      heading4: "Opposition and Patience",
      para4: "Many people opposed him despite his miracles. He remained patient and continued spreading Allah’s message.",
      heading5: "Ascension and Guidance",
      para5: "Allah raised Hazrat Isa (A.S) to the heavens. His teachings continue to guide humanity."
    },
    ur: {
      heading1: "حضرت عیسیٰ علیہ السلام کی پیدائش اور ابتدائی زندگی",
      para1: "حضرت عیسیٰ علیہ السلام بغیر باپ کے حضرت مریم علیہ السلام سے اللہ کے حکم سے پیدا ہوئے۔",
      heading2: "قوم کی طرف دعوت",
      para2: "حضرت عیسیٰ علیہ السلام نے لوگوں کو صرف اللہ کی عبادت کی دعوت دی۔",
      heading3: "اللہ کے اذن سے معجزات",
      para3: "آپ نے اللہ کے حکم سے مردوں کو زندہ کیا اور مٹی کے پرندے بنائے۔",
      heading4: "مخالفت اور صبر",
      para4: "لوگوں نے مخالفت کی مگر آپ نے صبر کا مظاہرہ کیا۔",
      heading5: "آسمانوں میں عروج",
      para5: "اللہ نے حضرت عیسیٰ علیہ السلام کو آسمانوں پر اٹھا لیا۔"
    }
  };

  const t = storyText[lang];

  return (
    <ScrollView style={styles.container}>
      
      {/* Top Image */}    
      <Image source={require('./assets/1_kOeMXnbFzmTjgy6nOL1GEA.jpg')} style={styles.topImage} />

      <View style={styles.langBox}>
        <Text style={styles.langText}>READ STORY IN</Text>
        <TouchableOpacity style={styles.langBtn} onPress={() => setLang('en')}>
          <Text>English</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.langBtn} onPress={() => setLang('ur')}>
          <Text>اردو</Text>
        </TouchableOpacity>
      </View>

      <Text style={styles.heading}>{t.heading1}</Text>
      <Text style={styles.paragraph}>{t.para1}</Text>

      <Text style={styles.heading}>{t.heading2}</Text>
      <Text style={styles.paragraph}>{t.para2}</Text>

      {/* Top Image */}    
      <Image source={require('./assets/isa (1).jpg')} style={styles.topImage} />

      <Text style={styles.heading}>{t.heading3}</Text>
      <Text style={styles.paragraph}>{t.para3}</Text>

      {/* Top Image */}    
      <Image source={require('./assets/isa (2).jpg')} style={styles.topImage} />

      <Text style={styles.heading}>{t.heading4}</Text>
      <Text style={styles.paragraph}>{t.para4}</Text>

      <Text style={styles.heading}>{t.heading5}</Text>
      <Text style={styles.paragraph}>{t.para5}</Text>

      {/* Back Button */}
       <TouchableOpacity
        style={styles.backBtn}
        onPress={() => navigation.goBack()} // Back to Stories
      >
        <Text style={styles.backText}>← Back to Stories</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#fff5f3',
    padding: 15
  },
  topImage: {
    width: '100%',
    height: 220,
    borderRadius: 15,
    marginBottom: 20
  },
  langBox: {
    backgroundColor: '#ffc1bd',
    padding: 10,
    borderRadius: 15,
    alignItems: 'center',
    marginBottom: 20
  },
  langText: {
    fontWeight: 'bold',
    marginBottom: 8
  },
  langBtn: {
    backgroundColor: '#fff',
    padding: 8,
    borderRadius: 20,
    marginVertical: 4,
    width: 120,
    alignItems: 'center'
  },
  heading: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#003366',
    textAlign: 'center',
    marginVertical: 10
  },
  paragraph: {
    fontSize: 16,
    textAlign: 'center',
    lineHeight: 24,
    marginBottom: 15
  },
  image: {
    width: '100%',
    height: 200,
    borderRadius: 15,
    marginVertical: 15
  },
  backBtn: {
    backgroundColor: '#ffc1bd',
    padding: 15,
    borderRadius: 25,
    alignItems: 'center',
    marginVertical: 30
  },
backText: {
  fontSize: 18,
  fontWeight: "bold",
},
});