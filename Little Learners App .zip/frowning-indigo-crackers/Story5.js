import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Image,
  TouchableOpacity,
} from "react-native";
import { StatusBar } from "expo-status-bar";

export default function Story5Screen({ navigation }){
  const [lang, setLang] = useState("en");

  const storyText = {
    en: {
      heading1: "Hazrat Yusuf (A.S) and His Early Trials",
      para1:
        "Hazrat Yusuf (A.S), son of Hazrat Yaqub (A.S), was dearly loved by his father. His brothers became jealous and threw him into a well. Allah guided him and he reached Egypt, where he was sold as a slave.",
      heading2: "The Test of Integrity",
      para2:
        "In Egypt, Yusuf (A.S) was bought by Al-Aziz. When his wife tried to tempt him, Yusuf (A.S) resisted with faith and patience. Despite his innocence, he was imprisoned.",
      heading3: "Interpretation of Dreams and Rise",
      para3:
        "In prison, Yusuf (A.S) interpreted dreams. Later, he interpreted the king’s dream of famine and prosperity. Impressed, the king made him a minister in Egypt.",
      heading4: "Reunion and Lessons",
      para4:
        "During famine, Yusuf’s brothers came for help. He forgave them and reunited with his father. His life teaches patience, trust in Allah, integrity, and forgiveness.",
    },
    ur: {
      heading1: "حضرت یوسف علیہ السلام اور ابتدائی آزمائشیں",
      para1:
        "حضرت یوسف علیہ السلام حضرت یعقوب علیہ السلام کے بیٹے تھے اور اپنے والد کے بہت محبوب تھے۔ بھائیوں نے حسد میں انہیں کنویں میں ڈال دیا، مگر اللہ نے ان کی حفاظت کی۔",
      heading2: "اخلاقی آزمائش",
      para2:
        "مصر میں حضرت یوسف علیہ السلام کو حضرت عزیز نے خریدا۔ عزیز کی بیوی نے بہکانے کی کوشش کی، مگر یوسف علیہ السلام نے صبر اور ایمان کا مظاہرہ کیا۔",
      heading3: "خوابوں کی تعبیر اور عروج",
      para3:
        "قید میں حضرت یوسف علیہ السلام نے خوابوں کی تعبیر کی۔ بعد میں بادشاہ کے خواب کی تعبیر بتانے پر انہیں مصر کا وزیر بنایا گیا۔",
      heading4: "ملاقات اور سبق",
      para4:
        "قحط کے دوران بھائی مدد کے لیے آئے۔ حضرت یوسف علیہ السلام نے انہیں معاف کیا اور اپنے والد سے ملاقات کی۔ ان کی زندگی صبر اور معافی کا سبق دیتی ہے۔",
    },
  };

  return (
    <ScrollView style={styles.container}>
      {/* Top Image */}
      {/* Top Image */}    
      <Image source={require('./assets/yusuf.png')} style={styles.topImage} />

      {/* Language Switch */}
      <View style={styles.langBox}>
        <Text style={styles.langText}>READ STORY IN</Text>
        <TouchableOpacity
          style={styles.langBtn}
          onPress={() => setLang("en")}
        >
          <Text>English</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.langBtn}
          onPress={() => setLang("ur")}
        >
          <Text>اردو</Text>
        </TouchableOpacity>
      </View>

      {/* Story */}
      <Text style={styles.heading}>{storyText[lang].heading1}</Text>
      <Text style={styles.para}>{storyText[lang].para1}</Text>

     {/* Top Image */}    
<Image source={require('./assets/yusuf (1).png')} style={styles.topImage} />

      <Text style={styles.heading}>{storyText[lang].heading2}</Text>
      <Text style={styles.para}>{storyText[lang].para2}</Text>

     {/* Top Image */}    
      <Image source={require('./assets/yusuf (2).jpg')} style={styles.topImage} />

      <Text style={styles.heading}>{storyText[lang].heading3}</Text>
      <Text style={styles.para}>{storyText[lang].para3}</Text>

      {/* Top Image */}    
      <Image source={require('./assets/yusuf (3).jpg')} style={styles.topImage} />

      <Text style={styles.heading}>{storyText[lang].heading4}</Text>
      <Text style={styles.para}>{storyText[lang].para4}</Text>

        {/* Back Button */}
       <TouchableOpacity
        style={styles.backBtn}
        onPress={() => navigation.goBack()} // Back to Stories
      >
        <Text style={styles.backText}>← Back to Stories</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "#fff5f3",
    padding: 15,
  },
  topImage: {
    width: "100%",
    height: 240,
    borderRadius: 15,
    marginBottom: 20,
  },
  langBox: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#ffc1bd",
    padding: 10,
    borderRadius: 15,
    marginBottom: 20,
    gap: 10,
  },
  langText: {
    fontWeight: "bold",
  },
  langBtn: {
    backgroundColor: "#fff",
    paddingVertical: 6,
    paddingHorizontal: 15,
    borderRadius: 20,
  },
  heading: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#003366",
    textAlign: "center",
    marginTop: 20,
  },
  para: {
    fontSize: 16,
    textAlign: "center",
    lineHeight: 24,
    marginTop: 10,
  },
  storyImg: {
    width: "80%",
    height: 260,
    borderRadius: 35,
    alignSelf: "center",
    marginVertical: 20,
  },
  backBtn: {
    backgroundColor: "#ffc1bd",
    padding: 15,
    borderRadius: 25,
    marginVertical: 30,
    alignItems: "center",
  },
  backText: {
    fontSize: 18,
    fontWeight: "bold",
  },
});