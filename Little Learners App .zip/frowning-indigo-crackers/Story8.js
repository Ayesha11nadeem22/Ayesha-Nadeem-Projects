import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Image,
  ScrollView,
  TouchableOpacity
} from 'react-native';
import { StatusBar } from "expo-status-bar";

export default function Story8Screen({ navigation }) {

  const [lang, setLang] = useState("en");

  const storyText = {
    en: {
      heading1: "The Kingdom of Hazrat Sulaiman (A.S)",
      para1: "Hazrat Sulaiman (A.S), the son of Hazrat Dawood (A.S), was blessed by Allah with wisdom, knowledge, and a powerful kingdom. He ruled with fairness and justice. Allah granted him control over the wind, jinn, and animals.",

      heading2: "The Gift of Understanding Animals",
      para2: "Hazrat Sulaiman (A.S) was gifted the ability to understand the language of animals. Birds, insects, and all creatures could communicate with him.",

      heading3: "The Ant’s Warning",
      para3: "While marching with his army, Hazrat Sulaiman (A.S) heard an ant warning others to go into their homes. He smiled and thanked Allah for His blessings.",

      heading4: "The Visit of the Queen of Sheba",
      para4: "The Queen of Sheba tested Hazrat Sulaiman (A.S) with gifts. Seeing his wisdom and justice, she accepted faith in Allah.",

      heading5: "Wisdom and Lessons for Humanity",
      para5: "Hazrat Sulaiman (A.S) ruled with gratitude and humility. His life teaches us that real power lies in wisdom and faith.",

      para6: "His wisdom and leadership continue to inspire people. Knowledge and humility are the greatest treasures from Allah."
    },

    ur: {
      heading1: "حضرت سلیمان علیہ السلام کی بادشاہت",
      para1: "حضرت سلیمان علیہ السلام کو اللہ نے حکمت، علم اور عظیم بادشاہت عطا کی۔ وہ عدل اور انصاف کے ساتھ حکومت کرتے تھے۔",

      heading2: "جانوروں کی زبان سمجھنے کا معجزہ",
      para2: "حضرت سلیمان علیہ السلام کو جانوروں کی بات سمجھنے کی خاص صلاحیت عطا کی گئی تھی۔",

      heading3: "چیونٹی کی تنبیہ",
      para3: "حضرت سلیمان علیہ السلام نے چیونٹی کی بات سن کر اللہ کا شکر ادا کیا۔",

      heading4: "ملکہ سبا کی آمد",
      para4: "ملکہ سبا حضرت سلیمان علیہ السلام کی حکمت دیکھ کر اللہ پر ایمان لے آئیں۔",

      heading5: "حکمت اور انسانیت کے لئے سبق",
      para5: "حضرت سلیمان علیہ السلام کی زندگی ہمیں عاجزی، انصاف اور ایمان سکھاتی ہے۔",

      para6: "علم اور عاجزی اللہ کی سب سے بڑی نعمتیں ہیں۔"
    }
  };

  const t = storyText[lang];

  return (
    <ScrollView style={styles.container}>

      {/* Top Image */}
     {/* Top Image */}    
      <Image source={require('./assets/story-of-prophet-sulaiman-as.webp')} style={styles.topImage} />

      {/* Language Switch */}
      <View style={styles.languageBox}>
        <Text style={styles.langText}>READ STORY IN</Text>

        <TouchableOpacity style={styles.langBtn} onPress={() => setLang("en")}>
          <Text>English</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.langBtn} onPress={() => setLang("ur")}>
          <Text>اردو</Text>
        </TouchableOpacity>
      </View>

      {/* Story Content */}
      <Text style={styles.heading}>{t.heading1}</Text>
      <Text style={styles.para}>{t.para1}</Text>

      <Text style={styles.heading}>{t.heading2}</Text>
      <Text style={styles.para}>{t.para2}</Text>

     {/* Top Image */}    
      <Image source={require('./assets/suliman (1).jpg')} style={styles.topImage} />

      <Text style={styles.heading}>{t.heading3}</Text>
      <Text style={styles.para}>{t.para3}</Text>

      {/* Top Image */}    
      <Image source={require('./assets/suliman (2).jpg')} style={styles.topImage} />

      <Text style={styles.heading}>{t.heading4}</Text>
      <Text style={styles.para}>{t.para4}</Text>

      <Text style={styles.heading}>{t.heading5}</Text>
      <Text style={styles.para}>{t.para5}</Text>

      {/* Top Image */}    
      <Image source={require('./assets/suliman (3).jpg')} style={styles.topImage} />

      <Text style={styles.para}>{t.para6}</Text>

      {/* Back Button */}
       <TouchableOpacity
        style={styles.backBtn}
        onPress={() => navigation.goBack()} // Back to Stories
      >
        <Text style={styles.backText}>← Back to Stories</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#fff5f3',
    padding: 15
  },
  topImage: {
    width: '100%',
    height: 200,
    borderRadius: 15,
    marginBottom: 20
  },
  languageBox: {
    backgroundColor: '#ffc1bd',
    padding: 15,
    borderRadius: 15,
    alignItems: 'center',
    marginBottom: 20
  },
  langText: {
    fontWeight: 'bold',
    marginBottom: 10
  },
  langBtn: {
    backgroundColor: '#fff',
    padding: 10,
    borderRadius: 20,
    marginVertical: 5,
    width: 130,
    alignItems: 'center'
  },
  heading: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#003366',
    textAlign: 'center',
    marginTop: 20
  },
  para: {
    fontSize: 16,
    textAlign: 'center',
    marginTop: 10,
    lineHeight: 24
  },
  storyImage: {
    width: '100%',
    height: 180,
    borderRadius: 15,
    marginVertical: 15
  },
  backBtn: {
    backgroundColor: '#ffc1bd',
    padding: 15,
    borderRadius: 25,
    alignItems: 'center',
    marginVertical: 30
  },
backText: {
  fontSize: 18,
  fontWeight: "bold",
},
});