import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Image,
  TouchableOpacity,
} from "react-native";
import { StatusBar } from "expo-status-bar";

export default function Story4Screen({ navigation }) {
  const [lang, setLang] = useState("en");

  const storyText = {
    en: {
      heading1: "Hazrat Ishmael (A.S) and His Obedience",
      para1:
        "Hazrat Ishmael (A.S), the son of Prophet Ibrahim (A.S), was known for his patience and complete obedience to Allah. When left in the desert with his mother Hajar (A.S), Allah blessed them with the miraculous Zamzam water.",
      heading2: "The Test of Patience",
      para2:
        "Baby Ishmael (A.S) cried from thirst in the barren desert of Makkah. His mother ran between Safa and Marwa. Allah sent Angel Jibreel (A.S), and Zamzam water flowed beneath Ismail’s feet.",
      heading3: "The Test of Sacrifice",
      para3:
        "Allah commanded Ibrahim (A.S) to sacrifice Ishmael (A.S). Ismail (A.S) replied with obedience: 'Father, do as you are commanded.' This showed complete submission to Allah.",
      heading4: "Lessons from His Life",
      para4:
        "Hazrat Ishmael (A.S) teaches us patience, obedience to Allah, respect for parents, and trust in Allah’s wisdom.",
    },
    ur: {
      heading1: "حضرت اسماعیل علیہ السلام اور اطاعت",
      para1:
        "حضرت اسماعیل علیہ السلام، حضرت ابراہیم علیہ السلام کے فرزند تھے اور صبر و اطاعت میں ممتاز تھے۔ صحرا میں والدہ کے ساتھ چھوڑے جانے پر اللہ نے زمزم کا معجزہ عطا فرمایا۔",
      heading2: "صبر کی آزمائش",
      para2:
        "حضرت ہاجرہ علیہا السلام صفا اور مروہ کے درمیان پانی کی تلاش میں دوڑیں۔ اللہ نے حضرت جبریل علیہ السلام کو بھیجا اور زمزم کا چشمہ جاری ہوا۔",
      heading3: "قربانی کی آزمائش",
      para3:
        "جب حضرت ابراہیم علیہ السلام نے قربانی کا حکم بتایا تو حضرت اسماعیل علیہ السلام نے فرمایا: ابا جان! جو حکم ہوا ہے وہ کیجیے۔",
      heading4: "ان کی زندگی کے اسباق",
      para4:
        "حضرت اسماعیل علیہ السلام کی زندگی ہمیں صبر، اطاعت، والدین کا احترام اور اللہ پر بھروسہ سکھاتی ہے۔",
    },
  };

  return (
    <ScrollView style={styles.container}>
      {/* Top Image */}
      {/* Top Image */}    
      <Image source={require('./assets/prophet-ishamel.png')} style={styles.topImage} />
     

      {/* Language Switch */}
      <View style={styles.langBox}>
        <Text style={styles.langText}>READ STORY IN</Text>
        <TouchableOpacity
          style={styles.langBtn}
          onPress={() => setLang("en")}
        >
          <Text>English</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.langBtn}
          onPress={() => setLang("ur")}
        >
          <Text>اردو</Text>
        </TouchableOpacity>
      </View>

      {/* Story Content */}
      <Text style={styles.heading}>{storyText[lang].heading1}</Text>
      <Text style={styles.para}>{storyText[lang].para1}</Text>

      {/* Top Image */}    
      <Image source={require('./assets/zamzam.jpg')} style={styles.topImage} />

      <Text style={styles.heading}>{storyText[lang].heading2}</Text>
      <Text style={styles.para}>{storyText[lang].para2}</Text>

      {/* Top Image */}    
      <Image source={require('./assets/zamzam (2).jpg')} style={styles.topImage} />

      <Text style={styles.heading}>{storyText[lang].heading3}</Text>
      <Text style={styles.para}>{storyText[lang].para3}</Text>

     {/* Top Image */}    
      <Image source={require('./assets/zamzam (3).jpg')} style={styles.topImage} />

      <Text style={styles.heading}>{storyText[lang].heading4}</Text>
      <Text style={styles.para}>{storyText[lang].para4}</Text>

      {/* Back Button */}
        {/* Back Button */}
       <TouchableOpacity
        style={styles.backBtn}
        onPress={() => navigation.goBack()} // Back to Stories
      >
        <Text style={styles.backText}>← Back to Stories</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "#fff5f3",
    padding: 15,
  },
  topImage: {
    width: "100%",
    height: 230,
    borderRadius: 15,
    marginBottom: 20,
  },
  langBox: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#ffc1bd",
    padding: 10,
    borderRadius: 15,
    marginBottom: 20,
    gap: 10,
  },
  langText: {
    fontWeight: "bold",
  },
  langBtn: {
    backgroundColor: "#fff",
    paddingVertical: 6,
    paddingHorizontal: 15,
    borderRadius: 20,
  },
  heading: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#003366",
    textAlign: "center",
    marginTop: 20,
  },
  para: {
    fontSize: 16,
    textAlign: "center",
    lineHeight: 24,
    marginTop: 10,
  },
  storyImg: {
    width: "80%",
    height: 220,
    borderRadius: 35,
    alignSelf: "center",
    marginVertical: 20,
  },
  backBtn: {
    backgroundColor: "#ffc1bd",
    padding: 15,
    borderRadius: 25,
    marginVertical: 30,
    alignItems: "center",
  },
  backText: {
    fontSize: 18,
    fontWeight: "bold",
  },
});