import React, { useState } from "react";
import { View, Text, TouchableOpacity, StyleSheet, Modal } from "react-native";

export default function Quiz5Screen({ navigation }) {
  const [unlocked, setUnlocked] = useState(1);
  const [currentLevel, setCurrentLevel] = useState(null);
  const [index, setIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [showQuiz, setShowQuiz] = useState(false);
  const [popupVisible, setPopupVisible] = useState(false);
  const [popupTitle, setPopupTitle] = useState("");
  const [popupMsg, setPopupMsg] = useState("");
  const [showPrize, setShowPrize] = useState(false);

  const quizData = {
    1: [
      {q:"5 + 3 =", o:["7","8","9","6"], a:1},
      {q:"10 - 4 =", o:["6","5","7","4"], a:0},
      {q:"2 + 6 =", o:["7","8","9","6"], a:1},
      {q:"9 - 3 =", o:["6","7","5","4"], a:0},
      {q:"7 + 2 =", o:["8","9","10","7"], a:1},
      {q:"12 - 5 =", o:["6","7","8","9"], a:2},
      {q:"3 + 4 =", o:["6","7","8","5"], a:1},
      {q:"6 - 2 =", o:["3","4","5","6"], a:1},
      {q:"8 + 1 =", o:["8","9","10","7"], a:1},
      {q:"15 - 7 =", o:["7","8","9","6"], a:1}
    ],
    2: [
      {q:"3 × 4 =", o:["12","11","14","10"], a:0},
      {q:"5 × 5 =", o:["20","25","30","24"], a:1},
      {q:"6 × 2 =", o:["12","10","14","11"], a:0},
      {q:"7 × 3 =", o:["20","21","22","19"], a:1},
      {q:"9 × 2 =", o:["18","17","19","16"], a:0},
      {q:"4 × 6 =", o:["22","24","26","20"], a:1},
      {q:"8 × 3 =", o:["24","23","25","22"], a:0},
      {q:"2 × 7 =", o:["14","12","15","13"], a:0},
      {q:"10 × 2 =", o:["20","21","19","22"], a:0},
      {q:"5 × 6 =", o:["30","28","32","25"], a:0}
    ],
    3: [
      {q:"How many hours in a day?", o:["12","24","18","10"], a:1},
      {q:"How many minutes in an hour?", o:["50","60","70","45"], a:1},
      {q:"How many seconds in a minute?", o:["50","55","60","65"], a:2},
      {q:"Half of an hour is?", o:["20 min","30 min","25 min","15 min"], a:1},
      {q:"Quarter of an hour is?", o:["15 min","20 min","30 min","10 min"], a:0},
      {q:"Which comes after 11:59?", o:["12:00","11:60","12:59","11:58"], a:0},
      {q:"How many hours from 6 AM to 12 PM?", o:["5","6","7","8"], a:1},
      {q:"Midnight is?", o:["12 AM","12 PM","6 AM","6 PM"], a:0},
      {q:"Noon is?", o:["12 PM","12 AM","6 AM","6 PM"], a:0},
      {q:"1 hour = ? minutes", o:["50","60","45","55"], a:1}
    ],
    4: [
      {q:"How many sides does a triangle have?", o:["3","4","5","6"], a:0},
      {q:"How many sides does a rectangle have?", o:["3","4","5","6"], a:1},
      {q:"Which shape is round?", o:["Circle","Square","Triangle","Rectangle"], a:0},
      {q:"How many corners does a square have?", o:["3","4","5","6"], a:1},
      {q:"Which shape has 5 sides?", o:["Pentagon","Hexagon","Triangle","Square"], a:0},
      {q:"Which shape has no corners?", o:["Circle","Square","Triangle","Rectangle"], a:0},
      {q:"How many edges does a cube have?", o:["12","10","8","6"], a:0},
      {q:"Which shape is like a can?", o:["Cylinder","Cube","Sphere","Cone"], a:0},
      {q:"Which shape is like a ball?", o:["Sphere","Cube","Cylinder","Rectangle"], a:0},
      {q:"How many faces does a cube have?", o:["6","4","5","8"], a:0}
    ],
    5: [
      {q:"1 meter = ? centimeters", o:["100","10","1000","50"], a:0},
      {q:"1 kilogram = ? grams", o:["1000","100","500","2000"], a:0},
      {q:"1 liter = ? milliliters", o:["100","1000","500","2000"], a:1},
      {q:"Which is heavier?", o:["1 kg","500 g","2 g","100 g"], a:0},
      {q:"Which is longer?", o:["1 m","50 cm","75 cm","90 cm"], a:0},
      {q:"Which is lighter?", o:["200 g","1 kg","2 kg","500 g"], a:0},
      {q:"Which holds more water?", o:["1 L bottle","500 mL bottle","100 mL bottle","750 mL bottle"], a:0},
      {q:"Which is shorter?", o:["30 cm","1 m","50 cm","75 cm"], a:0},
      {q:"Which is equal to 1000 g?", o:["1 kg","1 L","100 g","500 g"], a:0},
      {q:"Which is equal to 1000 mL?", o:["1 L","1 kg","500 mL","2 L"], a:0}
    ]
  };

  const startLevel = (lv) => {
    setCurrentLevel(lv);
    setIndex(0);
    setScore(0);
    setShowQuiz(true);
  };

  const chooseOption = (i) => {
    if (i === quizData[currentLevel][index].a) setScore(score + 1);
    next();
  };

  const next = () => {
    if (index < 9) setIndex(index + 1);
    else finishLevel();
  };

  const finishLevel = () => {
    const pass = score >= 7;
    if (pass) {
      if (currentLevel === 5) {
        setPopupTitle("🏆 WELL DONE 🏆");
        setPopupMsg(`You completed all 5 levels!\nScore: ${score}/10`);
        setUnlocked(6);
        setShowPrize(true);
      } else {
        setPopupTitle(`Level ${currentLevel} Passed ✅`);
        setPopupMsg(`Score: ${score}/10\nNext Level Unlocked`);
        if (unlocked === currentLevel) setUnlocked(unlocked + 1);
      }
    } else {
      setPopupTitle(`Level ${currentLevel} Failed ❌`);
      setPopupMsg(`Score: ${score}/10\nTry Again`);
    }
    setPopupVisible(true);
    setShowQuiz(false);
  };

  return (
    <View style={styles.container}>

      {/* LEVELS */}
      {!showQuiz && !showPrize && unlocked < 6 && (
        <View>
          <Text style={styles.heading}>➗ Math Quiz</Text>
          <View style={styles.levelGrid}>
            {[1,2,3,4,5].map(lv => (
              <TouchableOpacity
                key={lv}
                disabled={lv > unlocked}
                style={[styles.levelBox, lv > unlocked && styles.locked]}
                onPress={() => startLevel(lv)}>
                <Text style={styles.levelText}>{lv > unlocked ? "🔒" : ""} Level {lv}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      )}

      {/* PRIZE */}
      {showPrize && (
        <View style={styles.prizeBox}>
          <Text style={styles.prizeText}>🏆 YOU PASSED ALL LEVELS 🏆</Text>
          <Text style={styles.star}>⭐⭐⭐</Text>
          <Text style={styles.prizeSmall}>Bravo! Allah bless you 🤍</Text>
        </View>
      )}

      {/* QUIZ */}
      {showQuiz && (
        <View>
          <Text style={styles.levelTitle}>Level {currentLevel}</Text>
          <Text style={styles.question}>Q{index+1}. {quizData[currentLevel][index].q}</Text>
          {quizData[currentLevel][index].o.map((opt,i)=>(
            <TouchableOpacity key={i} style={styles.optionBtn} onPress={()=>chooseOption(i)}>
              <Text style={styles.optionText}>{opt}</Text>
            </TouchableOpacity>
          ))}
        </View>
      )}

      {/* POPUP */}
      <Modal visible={popupVisible} transparent animationType="fade">
        <View style={styles.popup}>
          <View style={styles.popupContent}>
            <Text style={styles.popupTitle}>{popupTitle}</Text>
            <Text style={styles.popupMsg}>{popupMsg}</Text>
            <TouchableOpacity style={styles.popupBtn} onPress={()=>setPopupVisible(false)}>
              <Text style={styles.popupBtnText}>Continue</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* BACK BUTTON */}
      <TouchableOpacity style={styles.backBtn} onPress={()=>navigation.goBack()}>
        <Text style={styles.backBtnText}>← Back To Quizzes</Text>
      </TouchableOpacity>

    </View>
  );
}

const styles = StyleSheet.create({
  container:{flex:1,padding:20,backgroundColor:"#ddb7b7",paddingTop:60},
  heading:{fontSize:30,fontWeight:"bold",textAlign:"center",marginBottom:30},
  levelGrid:{flexDirection:"row",flexWrap:"wrap",justifyContent:"center"},
  levelBox:{backgroundColor:"#e07474",padding:20,borderRadius:14,margin:10,width:120,alignItems:"center"},
  locked:{backgroundColor:"#cccccc"},
  levelText:{fontSize:18,color:"white",fontWeight:"bold"},
  levelTitle:{fontSize:26,fontWeight:"bold",marginBottom:15},
  question:{fontSize:20,fontWeight:"500",marginBottom:20},
  optionBtn:{padding:12,backgroundColor:"#dfe6e9",marginVertical:6,borderRadius:10,borderWidth:2,borderColor:"#3f0202"},
  optionText:{fontSize:18},
  popup:{flex:1,backgroundColor:"rgba(0,0,0,0.6)",justifyContent:"center",alignItems:"center"},
  popupContent:{backgroundColor:"#dd9797",padding:30,borderRadius:20,width:300,alignItems:"center"},
  popupTitle:{fontSize:22,fontWeight:"bold",marginBottom:15},
  popupMsg:{fontSize:16,textAlign:"center",marginBottom:20},
  popupBtn:{backgroundColor:"#4e0404",padding:12,borderRadius:10,width:120},
  popupBtnText:{textAlign:"center",color:"white",fontSize:16},
  prizeBox:{alignItems:"center",marginTop:50},
  prizeText:{fontSize:26,fontWeight:"bold"},
  star:{fontSize:50,marginVertical:20},
  prizeSmall:{fontSize:18},

 // ✅ Back Button Styles (thoda neeche)
backBtn: {
  position: "absolute",
  top: "72%", // 65% se neeche, screen ke center ke qareeb
  alignSelf: "center",
  backgroundColor: "#0c417e",
  paddingVertical: 12,
  paddingHorizontal: 28,
  borderRadius: 30,
  elevation: 6
},
backBtnText: {
  color: "white",
  fontSize: 16,
  fontWeight: "bold"
}
});
