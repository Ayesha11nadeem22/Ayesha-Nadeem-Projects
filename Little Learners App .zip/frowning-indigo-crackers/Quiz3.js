import React, { useState } from "react";
import { View, Text, TouchableOpacity, StyleSheet, Modal } from "react-native";

export default function Quiz3Screen({ navigation }) {

  const [unlocked, setUnlocked] = useState(1);
  const [currentLevel, setCurrentLevel] = useState(0);
  const [index, setIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [selected, setSelected] = useState(null);
  const [showQuiz, setShowQuiz] = useState(false);
  const [popupVisible, setPopupVisible] = useState(false);
  const [popupTitle, setPopupTitle] = useState("");
  const [popupMsg, setPopupMsg] = useState("");
  const [showPrize, setShowPrize] = useState(false);

  // ❇️ QUIZ DATA
  const quizData = {
    1: [
      { q:"How many days are there in a week?", o:["5","6","7","8"], a:2 },
      { q:"Which animal is known as King of Jungle?", o:["Elephant","Lion","Tiger","Bear"], a:1 },
      { q:"What color is the sun?", o:["Blue","Yellow","Red","Green"], a:1 },
      { q:"How many eyes do we have?", o:["1","2","3","4"], a:1 },
      { q:"Which fruit is red?", o:["Banana","Apple","Grapes","Orange"], a:1 },
      { q:"Which shape has 3 sides?", o:["Circle","Square","Triangle","Rectangle"], a:2 },
      { q:"How many fingers on one hand?", o:["3","4","5","6"], a:2 },
      { q:"Which animal gives milk?", o:["Dog","Cow","Lion","Horse"], a:1 },
      { q:"Which day comes after Friday?", o:["Thursday","Saturday","Sunday","Monday"], a:1 },
      { q:"What do we breathe?", o:["Water","Food","Air","Fire"], a:2 }
    ],
    2: [
      { q:"How many months in a year?", o:["10","11","12","13"], a:2 },
      { q:"Which planet do we live on?", o:["Mars","Earth","Venus","Jupiter"], a:1 },
      { q:"Which is the largest animal?", o:["Elephant","Blue Whale","Giraffe","Lion"], a:1 },
      { q:"What color are leaves?", o:["Blue","Red","Green","Yellow"], a:2 },
      { q:"Which animal hops?", o:["Dog","Cat","Kangaroo","Cow"], a:2 },
      { q:"How many legs does a spider have?", o:["6","8","10","12"], a:1 },
      { q:"Which bird cannot fly?", o:["Sparrow","Crow","Penguin","Eagle"], a:2 },
      { q:"Which is a fruit?", o:["Potato","Carrot","Apple","Onion"], a:2 },
      { q:"Which is the hottest season?", o:["Winter","Summer","Autumn","Spring"], a:1 },
      { q:"How many hours in a day?", o:["12","18","24","30"], a:2 }
    ],
    3: [
      { q:"Which is the biggest planet?", o:["Earth","Mars","Jupiter","Venus"], a:2 },
      { q:"How many colors in rainbow?", o:["5","6","7","8"], a:2 },
      { q:"Which animal is very slow?", o:["Rabbit","Dog","Snail","Horse"], a:2 },
      { q:"Which sense organ helps us see?", o:["Ear","Nose","Eye","Tongue"], a:2 },
      { q:"Which is a water animal?", o:["Lion","Fish","Cat","Camel"], a:1 },
      { q:"Which object gives us light?", o:["Fan","Table","Bulb","Chair"], a:2 },
      { q:"Which is used for writing?", o:["Eraser","Pen","Scale","Book"], a:1 },
      { q:"How many legs does a dog have?", o:["2","3","4","5"], a:2 },
      { q:"Which animal has a trunk?", o:["Dog","Horse","Elephant","Tiger"], a:2 },
      { q:"Which shape is round?", o:["Square","Triangle","Circle","Rectangle"], a:2 }
    ],
    4: [
      { q:"Which gas do plants need?", o:["Oxygen","Carbon Dioxide","Nitrogen","Hydrogen"], a:1 },
      { q:"Which is the tallest animal?", o:["Elephant","Giraffe","Horse","Camel"], a:1 },
      { q:"Which month has the fewest days?", o:["January","February","March","April"], a:1 },
      { q:"Which is a means of transport?", o:["Chair","Car","Table","Bed"], a:1 },
      { q:"Which animal lives in water?", o:["Camel","Fish","Dog","Cat"], a:1 },
      { q:"Which organ helps us hear?", o:["Eye","Nose","Ear","Hand"], a:2 },
      { q:"Which is a vegetable?", o:["Apple","Banana","Carrot","Mango"], a:2 },
      { q:"Which day comes before Monday?", o:["Sunday","Friday","Tuesday","Wednesday"], a:0 },
      { q:"What do bees make?", o:["Milk","Honey","Water","Juice"], a:1 },
      { q:"Which animal has stripes?", o:["Lion","Zebra","Cow","Goat"], a:1 }
    ],
    5: [
      { q:"Which is the national animal of Pakistan?", o:["Tiger","Lion","Markhor","Deer"], a:2 },
      { q:"Which is the largest ocean?", o:["Indian","Atlantic","Pacific","Arctic"], a:2 },
      { q:"Which bird is a symbol of peace?", o:["Crow","Eagle","Pigeon","Owl"], a:2 },
      { q:"Which is used to tell time?", o:["Book","Clock","Pen","Table"], a:1 },
      { q:"Which animal is man's best friend?", o:["Cat","Horse","Dog","Cow"], a:2 },
      { q:"Which is the coldest place?", o:["Desert","Forest","Antarctica","River"], a:2 },
      { q:"Which is a wild animal?", o:["Cow","Goat","Lion","Sheep"], a:2 },
      { q:"Which sense helps us smell?", o:["Eye","Ear","Nose","Hand"], a:2 },
      { q:"Which shape has four equal sides?", o:["Circle","Triangle","Square","Oval"], a:2 },
      { q:"Which is a healthy drink?", o:["Cola","Milk","Juice","Tea"], a:1 }
    ]
  };

  const startLevel = (lv) => {
    setCurrentLevel(lv);
    setIndex(0);
    setScore(0);
    setSelected(null);
    setShowQuiz(true);
  };

  const chooseOption = (i) => {
    setSelected(i);
    if (i === quizData[currentLevel][index].a) setScore(score + 1);
    next();
  };

  const next = () => {
    if (index < 9) setIndex(index + 1);
    else finishLevel();
  };

  const finishLevel = () => {
    const pass = score >= 7;
    if (pass) {
      if (currentLevel === 5) {
        setPopupTitle("🏆 WELL DONE 🏆");
        setPopupMsg(`You completed all 5 levels!\nScore: ${score}/10`);
        setUnlocked(6);
        setShowPrize(true);
      } else {
        setPopupTitle(`Level ${currentLevel} Passed ✅`);
        setPopupMsg(`Score: ${score}/10\nNext Level Unlocked`);
        if (unlocked === currentLevel) setUnlocked(unlocked + 1);
      }
    } else {
      setPopupTitle(`Level ${currentLevel} Failed ❌`);
      setPopupMsg(`Score: ${score}/10\nTry Again`);
    }
    setPopupVisible(true);
    setShowQuiz(false);
  };

  return (
    <View style={styles.container}>

      {/* LEVELS */}
      {!showQuiz && !showPrize && unlocked < 6 && (
        <View>
          <Text style={styles.heading}>🌍 GK Quiz</Text>
          <View style={styles.levelGrid}>
            {[1,2,3,4,5].map(lv => (
              <TouchableOpacity
                key={lv}
                disabled={lv > unlocked}
                style={[styles.levelBox, lv > unlocked && styles.locked]}
                onPress={()=>startLevel(lv)}>
                <Text style={styles.levelText}>{lv > unlocked ? "🔒" : ""} Level {lv}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      )}

      {/* PRIZE */}
      {showPrize && (
        <View style={styles.prizeBox}>
          <Text style={styles.prizeText}>🏆 YOU PASSED ALL LEVELS 🏆</Text>
          <Text style={styles.star}>⭐⭐⭐</Text>
          <Text style={styles.prizeSmall}>Bravo! Allah bless you 🤍</Text>
        </View>
      )}

      {/* QUIZ */}
      {showQuiz && (
        <View>
          <Text style={styles.levelTitle}>Level {currentLevel}</Text>
          <Text style={styles.question}>Q{index+1}. {quizData[currentLevel][index].q}</Text>
          {quizData[currentLevel][index].o.map((opt,i)=>(
            <TouchableOpacity key={i} style={styles.optionBtn} onPress={()=>chooseOption(i)}>
              <Text style={styles.optionText}>{opt}</Text>
            </TouchableOpacity>
          ))}
        </View>
      )}

      {/* POPUP */}
      <Modal visible={popupVisible} transparent animationType="fade">
        <View style={styles.popup}>
          <View style={styles.popupContent}>
            <Text style={styles.popupTitle}>{popupTitle}</Text>
            <Text style={styles.popupMsg}>{popupMsg}</Text>
            <TouchableOpacity style={styles.popupBtn} onPress={()=>setPopupVisible(false)}>
              <Text style={styles.popupBtnText}>Continue</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* BACK BUTTON */}
      <TouchableOpacity style={styles.backBtn} onPress={()=>navigation.goBack()}>
        <Text style={styles.backBtnText}>← Back To Quizzes</Text>
      </TouchableOpacity>

    </View>
  );
}

// ✅ STYLES
const styles = StyleSheet.create({
  container:{flex:1,padding:20,backgroundColor:"#e5d8f0",paddingTop:60},
  heading:{fontSize:30,fontWeight:"bold",textAlign:"center",marginBottom:30},
  levelGrid:{flexDirection:"row",flexWrap:"wrap",justifyContent:"center"},
  levelBox:{backgroundColor:"#b883e9",padding:20,borderRadius:14,margin:10,width:120,alignItems:"center"},
  locked:{backgroundColor:"#cccccc"},
  levelText:{fontSize:18,color:"white",fontWeight:"bold"},
  levelTitle:{fontSize:26,fontWeight:"bold",marginBottom:15},
  question:{fontSize:20,fontWeight:"500",marginBottom:20},
  optionBtn:{padding:12,backgroundColor:"#d8c0f0",marginVertical:6,borderRadius:10,borderWidth:2,borderColor:"#4c12a8"},
  optionText:{fontSize:18},
  popup:{flex:1,backgroundColor:"rgba(0,0,0,0.6)",justifyContent:"center",alignItems:"center"},
  popupContent:{backgroundColor:"#cf97dd",padding:30,borderRadius:20,width:300,alignItems:"center"},
  popupTitle:{fontSize:22,fontWeight:"bold",marginBottom:15},
  popupMsg:{fontSize:16,textAlign:"center",marginBottom:20},
  popupBtn:{backgroundColor:"#330783",padding:12,borderRadius:10,width:120},
  popupBtnText:{textAlign:"center",color:"white",fontSize:16},
  prizeBox:{alignItems:"center",marginTop:50},
  prizeText:{fontSize:26,fontWeight:"bold"},
  star:{fontSize:50,marginVertical:20},
  prizeSmall:{fontSize:18},

  // ✅ Back Button (thoda neeche)
  // ✅ Back Button Styles (thoda neeche)
backBtn: {
  position: "absolute",
  top: "72%", // 65% se neeche, screen ke center ke qareeb
  alignSelf: "center",
  backgroundColor: "#0c417e",
  paddingVertical: 12,
  paddingHorizontal: 28,
  borderRadius: 30,
  elevation: 6
},
backBtnText: {
  color: "white",
  fontSize: 16,
  fontWeight: "bold"
}
});
