import React from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Dimensions,
} from "react-native";
import { StatusBar } from "expo-status-bar";
import { SafeAreaView } from "react-native-safe-area-context";


const { width } = Dimensions.get("window");
const CARD_WIDTH = width > 900 ? width / 3 - 24 : width > 520 ? width / 2 - 24 : width - 32;

const hadiths = [
  { id: 1, title: "Hadith on Intention" },
  { id: 2, title: "Hadith on Kindness" },
  { id: 3, title: "Hadith on Seeking Knowledge" },
  { id: 4, title: "Hadith on Honesty" },
  { id: 5, title: "Hadith on Sharing" },
  { id: 6, title: "Hadith on Helping Others" },
  { id: 7, title: "Hadith on Respecting Parents" },
  { id: 8, title: "Hadith on Good Manners" },
  { id: 9, title: "Hadith on Charity" },
  { id: 10, title: "Hadith on Patience" },
];

export default function HadithsScreen({ navigation }) {
  const renderItem = ({ item }) => (
    <View style={[styles.card, { width: CARD_WIDTH }]}>
      <Text style={styles.hadithNum}>Hadith {item.id}</Text>
      <Text style={styles.hadithTitle}>{item.title}</Text>

      <TouchableOpacity
        style={styles.btn}
        onPress={() => navigation.navigate(`Hadith${item.id}`)}

      >
        <Text style={styles.btnText}>let's read</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar style="dark" />

      <Text style={styles.heading}>🌸 Hadiths</Text>

     <FlatList
  data={hadiths}
  renderItem={renderItem}
  keyExtractor={(item) => item.id.toString()}
  numColumns={width > 900 ? 3 : width > 520 ? 2 : 1}
  columnWrapperStyle={
    width > 520 ? { gap: 16 } : null
  }
  contentContainerStyle={{ gap: 16, paddingBottom: 30 }}
  showsVerticalScrollIndicator={false}
/>

  </SafeAreaView>

  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: "#cfe4ff",
    borderRadius: 12,
    padding: 16,
    justifyContent: "space-between",
    elevation: 4,
  },
  hadithNum: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#0a2680",
  },
  hadithTitle: {
    fontSize: 18,
    textAlign: "center",
    marginVertical: 16,
    color: "#000",
  },
  btn: {
    backgroundColor: "#8fb7f5",
    paddingVertical: 10,
    borderRadius: 8,
    alignItems: "center",
  },
  btnText: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 14,
  },
  container: {
  flex: 1,
  backgroundColor: "#AABFFC",
  paddingHorizontal: 16,
  paddingBottom: 16,
  justifyContent: "flex-end",  // Heading aur content neeche align hoga
},
heading: {
  fontSize: 28,
  fontWeight: "bold",
  textAlign: "center",
  marginBottom: 30,
}
});
