import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Image,
  TouchableOpacity,
} from "react-native";
import { StatusBar } from "expo-status-bar";

export default function Story1Screen({ navigation }) {
  const [lang, setLang] = useState("en");

  const storyText = {
    en: {
      heading1: "The Creation of Hazrat Adam (A.S)",
      para1:
        "Allah, the Most Merciful, created Hazrat Adam (A.S) from clay. He shaped him carefully and then breathed His spirit into him. This made Hazrat Adam (A.S) the first human being with life and consciousness. Allah taught him the names and purposes of all things, giving him wisdom and knowledge that even the angels did not possess.",

      heading2: "Life in Jannah (Heaven)",
      para2:
        "After creating Hazrat Adam (A.S), Allah placed him in Jannah, a beautiful garden full of blessings, rivers, fruits, and happiness. Hazrat Adam (A.S) was instructed that he could enjoy everything except one forbidden tree. Later, Allah created Hazrat Hawwa (A.S) to be his companion.",

      heading3: "The Test and the Forbidden Tree",
      para3:
        "Shaytan (Iblis) whispered lies and tempted Hazrat Adam (A.S) and Hazrat Hawwa (A.S). They ate from the forbidden tree and realized their mistake. They immediately repented to Allah.",

      heading4: "Repentance and Mercy",
      para4:
        "Allah accepted their repentance and forgave them. He sent them to Earth as part of His plan and promised guidance through His prophets.",

      heading5: "Life on Earth and Lessons",
      para5:
        "Hazrat Adam (A.S) taught people to worship Allah and live righteously. His story teaches obedience, responsibility, and repentance.",

      para6:
        "Hazrat Adam (A.S) guided his children and reminded humanity of Allah’s mercy and guidance.",
    },

    ur: {
      heading1: "حضرت آدم علیہ السلام کی تخلیق",
      para1:
        "اللہ تعالیٰ نے حضرت آدم علیہ السلام کو مٹی سے پیدا کیا اور اپنی روح پھونکی۔ یوں وہ پہلے انسان بنے۔",

      heading2: "جنت میں زندگی",
      para2:
        "اللہ تعالیٰ نے حضرت آدم علیہ السلام کو جنت میں رکھا، جہاں ہر نعمت موجود تھی، سوائے ایک درخت کے۔",

      heading3: "آزمائش اور ممنوعہ درخت",
      para3:
        "شیطان نے حضرت آدم اور حضرت حوا کو بہکایا اور انہوں نے ممنوعہ درخت سے کھا لیا۔",

      heading4: "توبہ اور رحمت",
      para4:
        "اللہ تعالیٰ نے ان کی توبہ قبول کی اور زمین پر بھیج دیا۔",

      heading5: "زمین پر زندگی اور اسباق",
      para5:
        "حضرت آدم علیہ السلام نے لوگوں کو عبادت اور نیکی کی تعلیم دی۔",

      para6:
        "ان کی زندگی اللہ کی رحمت اور ہدایت کی یاد دہانی ہے۔",
    },
  };

  const t = storyText[lang];

  return (
    <ScrollView style={styles.container}>
      <StatusBar style="dark" />

      {/* Top Image */}    
      <Image source={require('./assets/story.jpg')} style={styles.topImage} />


      {/* Language Switch */}
      <View style={styles.languageBox}>
        <Text style={styles.languageText}>READ STORY IN</Text>

        <TouchableOpacity onPress={() => setLang("en")} style={styles.langBtn}>
          <Text>English</Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={() => setLang("ur")} style={styles.langBtn}>
          <Text>اردو</Text>
        </TouchableOpacity>
      </View>

      {/* Story Content */}
      <Text style={styles.heading}>{t.heading1}</Text>
      <Text style={styles.paragraph}>{t.para1}</Text>

      <Text style={styles.heading}>{t.heading2}</Text>
      <Text style={styles.paragraph}>{t.para2}</Text>

 <Image source={require('./assets/paradise-restored-no-people-GoodSalt-abwasnt50b.jpg')} style={styles.topImage} />

      <Text style={styles.heading}>{t.heading3}</Text>
      <Text style={styles.paragraph}>{t.para3}</Text>

<Image source={require('./assets/forbidden-fruit-1-GoodSalt-rhpas1376.jpg')} style={styles.topImage} />
    

      <Text style={styles.heading}>{t.heading4}</Text>
      <Text style={styles.paragraph}>{t.para4}</Text>

      <Text style={styles.heading}>{t.heading5}</Text>
      <Text style={styles.paragraph}>{t.para5}</Text>

<Image source={require('./assets/eden-restored-2-GoodSalt-pcmas0066_1.jpg')} style={styles.topImage} />


      <Text style={styles.paragraph}>{t.para6}</Text>

      {/* Back Button */}
       <TouchableOpacity
        style={styles.backBtn}
        onPress={() => navigation.goBack()} // Back to Stories
      >
        <Text style={styles.backText}>← Back to Stories</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: "#fff5f3",
    padding: 15,
  },

  topImage: {
    width: "100%",
    height: 200,
    borderRadius: 10,
    marginBottom: 20,
  },

  languageBox: {
    backgroundColor: "#ffc1bd",
    padding: 15,
    borderRadius: 15,
    alignItems: "center",
    marginBottom: 25,
  },

  languageText: {
    fontWeight: "bold",
    marginBottom: 10,
  },

  langBtn: {
    backgroundColor: "#fff",
    paddingVertical: 8,
    paddingHorizontal: 20,
    borderRadius: 20,
    marginVertical: 5,
  },

  heading: {
    fontSize: 26,
    fontWeight: "bold",
    color: "#003366",
    textAlign: "center",
    marginTop: 20,
  },

  paragraph: {
    fontSize: 18,
    lineHeight: 26,
    textAlign: "center",
    marginTop: 10,
  },

  image: {
    width: "100%",
    height: 180,
    borderRadius: 15,
    marginVertical: 20,
  },

  backBtn: {
    backgroundColor: "#ffc1bd",
    padding: 15,
    borderRadius: 25,
    marginVertical: 30,
    alignItems: "center",
  },

  backText: {
    fontSize: 18,
    fontWeight: "bold",
  },
});