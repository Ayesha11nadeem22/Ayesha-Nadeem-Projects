import React, { useState } from "react";
import { View, Text, TouchableOpacity, StyleSheet, Modal } from "react-native";

export default function Quiz4Screen({ navigation }) {
  const [unlocked, setUnlocked] = useState(1);
  const [currentLevel, setCurrentLevel] = useState(null);
  const [index, setIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [showQuiz, setShowQuiz] = useState(false);
  const [popupVisible, setPopupVisible] = useState(false);
  const [popupTitle, setPopupTitle] = useState("");
  const [popupMsg, setPopupMsg] = useState("");
  const [showPrize, setShowPrize] = useState(false);

  const quizData = {
    1: [
      {q:"Which word is a noun?", o:["Run","Apple","Quick","Beautiful"], a:1},
      {q:"Which word is a pronoun?", o:["Dog","Blue","He","Jump"], a:2},
      {q:"Which word is a verb?", o:["Cat","Run","Table","Red"], a:1},
      {q:"Which word is an adjective?", o:["Dog","Beautiful","Run","Apple"], a:1},
      {q:"Which is a proper noun?", o:["London","dog","car","city"], a:0},
      {q:"Which word shows action?", o:["Apple","Eat","Blue","Fast"], a:1},
      {q:"Which word is a conjunction?", o:["Run","Apple","And","Blue"], a:2},
      {q:"Which is an article?", o:["Dog","The","Run","Blue"], a:1},
      {q:"Which is a preposition?", o:["Circle","Apple","On","Cat"], a:2},
      {q:"Which word is an adverb?", o:["Quickly","Dog","Apple","Blue"], a:0}
    ],
    2: [
      {q:"Which is a singular noun?", o:["Dog","Dogs","Cats","Apples"], a:0},
      {q:"Which is a plural noun?", o:["Dog","Dogs","Apple","Car"], a:1},
      {q:"Which is a proper pronoun?", o:["Dog","Apple","She","Table"], a:2},
      {q:"Which is a common noun?", o:["Car","London","Sarah","Pakistan"], a:0},
      {q:"Which verb is in past tense?", o:["Go","Went","Gone","Going"], a:1},
      {q:"Which verb is in present tense?", o:["Went","Go","Gone","Going"], a:1},
      {q:"Which is a helping verb?", o:["Run","Dog","Is","Car"], a:2},
      {q:"Which is a possessive pronoun?", o:["Mine","Dog","Apple","Table"], a:0},
      {q:"Which word is a question word?", o:["Dog","Apple","Car","What"], a:3},
      {q:"Which is an interjection?", o:["Dog","Crow","Wow!","Apple"], a:2}
    ],
    3: [
      {q:"Which is a singular subject?", o:["She","They","We","Boys"], a:0},
      {q:"Which is a plural subject?", o:["He","They","She","It"], a:1},
      {q:"Which sentence is in past tense?", o:["I eat an apple.","I am eating an apple.","I will eat an apple.","I ate an apple."], a:3},
      {q:"Which sentence is in future tense?", o:["I am going to school.","I go to school.","I will go to school.","I went to school."], a:2},
      {q:"Which is a positive sentence?", o:["Don't eat that.","Never come.","I like ice cream.","I don't like ice cream."], a:2},
      {q:"Which is a negative sentence?", o:["He runs fast.","She eats apples.","I do not like ice cream.","I like ice cream."], a:2},
      {q:"Which is an interrogative sentence?", o:["Do you like apples?","I like apples.","He runs fast.","She eats apples."], a:0},
      {q:"Which is an imperative sentence?", o:["I like apples.","Close the door.","She is reading.","They are playing."], a:1},
      {q:"Which is a declarative sentence?", o:["Wow!","Stop!","Are you happy?","I am happy."], a:3},
      {q:"Which is an exclamatory sentence?", o:["She runs fast.","What a beautiful day!","I like apples.","They play football."], a:1}
    ],
    4: [
      {q:"Which is a singular pronoun?", o:["He","They","We","You"], a:0},
      {q:"Which is a plural pronoun?", o:["He","She","It","They"], a:3},
      {q:"Which verb shows action?", o:["Run","Is","Was","Are"], a:0},
      {q:"Which verb shows state of being?", o:["Run","Eat","Is","Jump"], a:2},
      {q:"Which is a coordinating conjunction?", o:["And","Because","Although","When"], a:0},
      {q:"Which is a subordinating conjunction?", o:["And","Because","Although","When"], a:1},
      {q:"Which is an indefinite article?", o:["A","The","This","That"], a:0},
      {q:"Which is a definite article?", o:["Some","A","An","The"], a:3},
      {q:"Which sentence is affirmative?", o:["I am happy.","I am not happy.","Don't go!","Wow!"], a:0},
      {q:"Which sentence is negative?", o:["I am happy.","I am not happy.","Wow!","Stop!"], a:1}
    ],
    5: [
      {q:"Which is a compound sentence?", o:["I like tea.","I like tea and he likes coffee.","He likes coffee.","Tea is hot."], a:1},
      {q:"Which is a complex sentence?", o:["I like tea.","Although it rained, we went out.","He likes coffee.","The sun is bright."], a:1},
      {q:"Which sentence is simple?", o:["Although it rained, we went out.","I like ice cream.","I like tea and he likes coffee.","Because he was late, we left."], a:1},
      {q:"Which word is a modal verb?", o:["Dog","Run","Apple","Can"], a:3},
      {q:"Which word shows possibility?", o:["Might","Dog","Car","Table"], a:0},
      {q:"Which word shows ability?", o:["He","She","Can","It"], a:2},
      {q:"Which word shows necessity?", o:["Eat","Run","Apple","Must"], a:3},
      {q:"Which word shows obligation?", o:["Dog","Car","Apple","Should"], a:3},
      {q:"Which is an action verb?", o:["Run","Is","Was","Are"], a:0},
      {q:"Which is a linking verb?", o:["Is","Run","Eat","Play"], a:0}
    ]
  };

  const startLevel = (lv) => {
    setCurrentLevel(lv);
    setIndex(0);
    setScore(0);
    setShowQuiz(true);
  };

  const chooseOption = (i) => {
    if (i === quizData[currentLevel][index].a) setScore(score + 1);
    next();
  };

  const next = () => {
    if (index < 9) setIndex(index + 1);
    else finishLevel();
  };

  const finishLevel = () => {
    const pass = score >= 7;
    if (pass) {
      if (currentLevel === 5) {
        setPopupTitle("🏆 WELL DONE 🏆");
        setPopupMsg(`You completed all 5 levels!\nScore: ${score}/10`);
        setUnlocked(6);
        setShowPrize(true);
      } else {
        setPopupTitle(`Level ${currentLevel} Passed ✅`);
        setPopupMsg(`Score: ${score}/10\nNext Level Unlocked`);
        if (unlocked === currentLevel) setUnlocked(unlocked + 1);
      }
    } else {
      setPopupTitle(`Level ${currentLevel} Failed ❌`);
      setPopupMsg(`Score: ${score}/10\nTry Again`);
    }
    setPopupVisible(true);
    setShowQuiz(false);
  };

  return (
    <View style={styles.container}>

      {/* LEVELS */}
      {!showQuiz && !showPrize && unlocked < 6 && (
        <View>
          <Text style={styles.heading}>📚 English Quiz</Text>
          <View style={styles.levelGrid}>
            {[1,2,3,4,5].map(lv => (
              <TouchableOpacity
                key={lv}
                disabled={lv > unlocked}
                style={[styles.levelBox, lv > unlocked && styles.locked]}
                onPress={() => startLevel(lv)}>
                <Text style={styles.levelText}>{lv > unlocked ? "🔒" : ""} Level {lv}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      )}

      {/* PRIZE */}
      {showPrize && (
        <View style={styles.prizeBox}>
          <Text style={styles.prizeText}>🏆 YOU PASSED ALL LEVELS 🏆</Text>
          <Text style={styles.star}>⭐⭐⭐</Text>
          <Text style={styles.prizeSmall}>Bravo! Allah bless you 🤍</Text>
        </View>
      )}

      {/* QUIZ */}
      {showQuiz && (
        <View>
          <Text style={styles.levelTitle}>Level {currentLevel}</Text>
          <Text style={styles.question}>Q{index+1}. {quizData[currentLevel][index].q}</Text>
          {quizData[currentLevel][index].o.map((opt,i)=>(
            <TouchableOpacity key={i} style={styles.optionBtn} onPress={()=>chooseOption(i)}>
              <Text style={styles.optionText}>{opt}</Text>
            </TouchableOpacity>
          ))}
        </View>
      )}

      {/* POPUP */}
      <Modal visible={popupVisible} transparent animationType="fade">
        <View style={styles.popup}>
          <View style={styles.popupContent}>
            <Text style={styles.popupTitle}>{popupTitle}</Text>
            <Text style={styles.popupMsg}>{popupMsg}</Text>
            <TouchableOpacity style={styles.popupBtn} onPress={()=>setPopupVisible(false)}>
              <Text style={styles.popupBtnText}>Continue</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* BACK BUTTON */}
      <TouchableOpacity style={styles.backBtn} onPress={()=>navigation.goBack()}>
        <Text style={styles.backBtnText}>← Back To Quizzes</Text>
      </TouchableOpacity>

    </View>
  );
}

const styles = StyleSheet.create({
  container:{flex:1,padding:20,backgroundColor:"#abeddd",paddingTop:60},
  heading:{fontSize:30,fontWeight:"bold",textAlign:"center",marginBottom:30},
  levelGrid:{flexDirection:"row",flexWrap:"wrap",justifyContent:"center"},
  levelBox:{backgroundColor:"#74e0c0",padding:20,borderRadius:14,margin:10,width:120,alignItems:"center"},
  locked:{backgroundColor:"#cccccc"},
  levelText:{fontSize:18,color:"white",fontWeight:"bold"},
  levelTitle:{fontSize:26,fontWeight:"bold",marginBottom:15},
  question:{fontSize:20,fontWeight:"500",marginBottom:20},
  optionBtn:{padding:12,backgroundColor:"#dfe6e9",marginVertical:6,borderRadius:10,borderWidth:2,borderColor:"#023f26"},
  optionText:{fontSize:18},
  popup:{flex:1,backgroundColor:"rgba(0,0,0,0.6)",justifyContent:"center",alignItems:"center"},
  popupContent:{backgroundColor:"#97ddd4",padding:30,borderRadius:20,width:300,alignItems:"center"},
  popupTitle:{fontSize:22,fontWeight:"bold",marginBottom:15},
  popupMsg:{fontSize:16,textAlign:"center",marginBottom:20},
  popupBtn:{backgroundColor:"#044e3c",padding:12,borderRadius:10,width:120},
  popupBtnText:{textAlign:"center",color:"white",fontSize:16},
  prizeBox:{alignItems:"center",marginTop:50},
  prizeText:{fontSize:26,fontWeight:"bold"},
  star:{fontSize:50,marginVertical:20},
  prizeSmall:{fontSize:18},

 // ✅ Back Button Styles (thoda neeche)
backBtn: {
  position: "absolute",
  top: "72%", // 65% se neeche, screen ke center ke qareeb
  alignSelf: "center",
  backgroundColor: "#0c417e",
  paddingVertical: 12,
  paddingHorizontal: 28,
  borderRadius: 30,
  elevation: 6
},
backBtnText: {
  color: "white",
  fontSize: 16,
  fontWeight: "bold"
}
});
