import React, { useState } from "react";
import { View, Text, TouchableOpacity, StyleSheet, Modal } from "react-native";

export default function Quiz6Screen({ navigation }) {
  const [unlocked, setUnlocked] = useState(1);
  const [currentLevel, setCurrentLevel] = useState(null);
  const [index, setIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [showQuiz, setShowQuiz] = useState(false);
  const [popupVisible, setPopupVisible] = useState(false);
  const [popupTitle, setPopupTitle] = useState("");
  const [popupMsg, setPopupMsg] = useState("");
  const [showPrize, setShowPrize] = useState(false);

  const quizData = {
    1: [
      {q:"Who is the founder of Pakistan?", o:["Allama Iqbal","Muhammad Ali Jinnah","Liaquat Ali Khan","Abdus Salam"], a:1},
      {q:"Who was the first Governor-General of Pakistan?", o:["Allama Iqbal","Zia-ul-Haq","Liaquat Ali Khan","Muhammad Ali Jinnah"], a:3},
      {q:"Who wrote the idea of Pakistan in 1930?", o:["Allama Iqbal","Sir Syed Ahmed Khan","Jinnah","Liaquat Ali Khan"], a:0},
      {q:"When did Pakistan become independent?", o:["14 August 1947","25 December 1971","1 January 1948","23 March 1940"], a:0},
      {q:"Which city was the first capital of Pakistan?", o:["Karachi","Islamabad","Quetta","Lahore"], a:0},
      {q:"Who was the first Prime Minister of Pakistan?", o:["Zulfikar Ali Bhutto","Liaquat Ali Khan","Imran Khan","Benazir Bhutto"], a:1},
      {q:"Which leader is called Quaid-e-Azam?", o:["Allama Iqbal","Benazir Bhutto","Liaquat Ali Khan","Muhammad Ali Jinnah"], a:3},
      {q:"Which leader is called Baba-e-Qaum?", o:["Jinnah","Allama Iqbal","Liaquat Ali Khan","Zia-ul-Haq"], a:1},
      {q:"Who was the first Pakistani to receive the Nobel Prize?", o:["Abdus Salam","Jinnah","Allama Iqbal","Benazir Bhutto"], a:0},
      {q:"Which famous poet inspired Pakistan’s creation?", o:["Faiz Ahmed Faiz","Allama Iqbal","Mirza Ghalib","Mohsin Naqvi"], a:1}
    ],
    2: [
      {q:"Which resolution demanded Pakistan?", o:["Lahore Resolution","Pakistan Resolution","Karachi Resolution","Islamabad Resolution"], a:0},
      {q:"When was the Lahore Resolution passed?", o:["11 September 1947","23 March 1940","14 August 1947","1 January 1940"], a:1},
      {q:"Which province was created in 1970?", o:["Punjab","Khyber Pakhtunkhwa","Balochistan","Sindh"], a:2},
      {q:"Who became Pakistan’s first female Prime Minister?", o:["Benazir Bhutto","Fatima Jinnah","Maryam Nawaz","Asma Jahangir"], a:0},
      {q:"Which event led to the creation of Bangladesh?", o:["1965 War","1971 War","1947 Independence","1999 War"], a:1},
      {q:"Who was the President during 1971?", o:["Muhammad Ayub Khan","Pervez Musharraf","Zulfikar Ali Bhutto","Yahya Khan"], a:3},
      {q:"Which city became Pakistan’s new capital in 1960?", o:["Rawalpindi","Karachi","Lahore","Islamabad"], a:3},
      {q:"Who was the first female elected member of National Assembly?", o:["Fatima Jinnah","Begum Ra’ana Liaquat Ali Khan","Benazir Bhutto","Shireen Mazari"], a:1},
      {q:"Which war was fought with India in 1965?", o:["Indo-Pak War","Third Kashmir War","Second Kashmir War","First Kashmir War"], a:2},
      {q:"Which river is called the lifeline of Pakistan?", o:["Jhelum","Chenab","Ravi","Indus"], a:3}
    ],
    3: [
      {q:"Which is Pakistan’s national monument?", o:["Faisal Mosque","Badshahi Mosque","Lahore Fort","Minar-e-Pakistan"], a:3},
      {q:"Which mosque is in Islamabad?", o:["Shah Jahan Mosque","Faisal Mosque","Badshahi Mosque","Wazir Khan Mosque"], a:1},
      {q:"Which is Pakistan’s national flower?", o:["Tulip","Jasmine","Rose","Sunflower"], a:1},
      {q:"Which is Pakistan’s national animal?", o:["Tiger","Elephant","Markhor","Lion"], a:2},
      {q:"Which is Pakistan’s national bird?", o:["Chakor","Parrot","Eagle","Peacock"], a:0},
      {q:"Which is Pakistan’s national fruit?", o:["Apple","Banana","Orange","Mango"], a:3},
      {q:"Which mountain is the highest in Pakistan?", o:["Rakaposhi","K2","Nanga Parbat","Gasherbrum"], a:1},
      {q:"Which river is longest in Pakistan?", o:["Indus","Chenab","Jhelum","Ravi"], a:0},
      {q:"Which desert is in Pakistan?", o:["Sahara","Karakum","Gobi","Thar Desert"], a:3},
      {q:"Which city is called the city of gardens?", o:["Peshawar","Islamabad","Lahore","Karachi"], a:2}
    ],
    4: [
      {q:"Who wrote Pakistan’s national anthem?", o:["Allama Iqbal","Faiz Ahmed Faiz","Hafeez Jullundhri","Ahmed Faraz"], a:2},
      {q:"Who was Pakistan’s first President?", o:["Iskander Mirza","Ayub Khan","Zulfikar Ali Bhutto","Pervez Musharraf"], a:0},
      {q:"Who introduced the 1973 Constitution?", o:["Zulfikar Ali Bhutto","Ayub Khan","Benazir Bhutto","Liaquat Ali Khan"], a:0},
      {q:"Which Prime Minister was executed in 1979?", o:["Liaquat Ali Khan","Benazir Bhutto","Zulfikar Ali Bhutto","Imran Khan"], a:2},
      {q:"Who was the founder of Pakistan People’s Party?", o:["Muhammad Ali Jinnah","Benazir Bhutto","Zulfikar Ali Bhutto","Nawaz Sharif"], a:2},
      {q:"Who was the first Chief of Army Staff?", o:["General Ayub Khan","General Zia","General Musharraf","General Frank Messervy"], a:3},
      {q:"Which leader introduced martial law in 1958?", o:["Zulfikar Ali Bhutto","Ayub Khan","Iskander Mirza","Benazir Bhutto"], a:2},
      {q:"Who was the first female Prime Minister of Pakistan?", o:["Fatima Jinnah","Maryam Nawaz","Asma Jahangir","Benazir Bhutto"], a:3},
      {q:"Which city hosts the Supreme Court of Pakistan?", o:["Lahore","Karachi","Peshawar","Islamabad"], a:3},
      {q:"Which political party did Imran Khan found?", o:["PTI","PPP","PML-N","MQM"], a:0}
    ],
    5: [
      {q:"Who was the first Muslim ruler of Delhi?", o:["Aurangzeb","Qutb-ud-din Aibak","Shah Jahan","Babur"], a:1},
      {q:"Which day is Pakistan Day?", o:["14 August","1 May","25 December","23 March"], a:3},
      {q:"Which war led to creation of Bangladesh?", o:["1965 War","1947 Partition","1971 War","1969 Crisis"], a:2},
      {q:"Who was Fatima Jinnah?", o:["Mother of Jinnah","Sister of Jinnah","Wife of Jinnah","Daughter of Jinnah"], a:1},
      {q:"Which movement led to Pakistan’s creation?", o:["Non-Cooperation Movement","Khilafat Movement","Indian Independence Movement","Pakistan Movement"], a:3},
      {q:"Which treaty ended Indo-Pak war of 1965?", o:["Simla Agreement","Tashkent Agreement","Lahore Resolution","Durand Line Agreement"], a:1},
      {q:"Who was the first female Governor of Sindh?", o:["Fatima Jinnah","Benazir Bhutto","Shireen Mazari","Durdana Ansari"], a:3},
      {q:"Which city is called City of Lights?", o:["Lahore","Karachi","Islamabad","Peshawar"], a:1},
      {q:"Which mountain range is in northern Pakistan?", o:["Alps","Himalayas","Andes","Rockies"], a:1},
      {q:"Which city hosted the first Pakistan Day parade?", o:["Lahore","Islamabad","Karachi","Peshawar"], a:0}
    ]
  };

  const startLevel = (lv) => {
    setCurrentLevel(lv);
    setIndex(0);
    setScore(0);
    setShowQuiz(true);
  };

  const chooseOption = (i) => {
    if (i === quizData[currentLevel][index].a) setScore(score + 1);
    next();
  };

  const next = () => {
    if (index < 9) setIndex(index + 1);
    else finishLevel();
  };

  const finishLevel = () => {
    const pass = score >= 7;
    if (pass) {
      if (currentLevel === 5) {
        setPopupTitle("🏆 WELL DONE 🏆");
        setPopupMsg(`You completed all 5 levels!\nScore: ${score}/10`);
        setUnlocked(6);
        setShowPrize(true);
      } else {
        setPopupTitle(`Level ${currentLevel} Passed ✅`);
        setPopupMsg(`Score: ${score}/10\nNext Level Unlocked`);
        if (unlocked === currentLevel) setUnlocked(unlocked + 1);
      }
    } else {
      setPopupTitle(`Level ${currentLevel} Failed ❌`);
      setPopupMsg(`Score: ${score}/10\nTry Again`);
    }
    setPopupVisible(true);
    setShowQuiz(false);
  };

  return (
    <View style={styles.container}>

      {/* LEVELS */}
      {!showQuiz && !showPrize && unlocked < 6 && (
        <View>
          <Text style={styles.heading}>📜 Pakistan History Quiz</Text>
          <View style={styles.levelGrid}>
            {[1,2,3,4,5].map(lv => (
              <TouchableOpacity
                key={lv}
                disabled={lv > unlocked}
                style={[styles.levelBox, lv > unlocked && styles.locked]}
                onPress={() => startLevel(lv)}>
                <Text style={styles.levelText}>{lv > unlocked ? "🔒" : ""} Level {lv}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      )}

      {/* PRIZE */}
      {showPrize && (
        <View style={styles.prizeBox}>
          <Text style={styles.prizeText}>🏆 YOU PASSED ALL LEVELS 🏆</Text>
          <Text style={styles.star}>⭐⭐⭐</Text>
          <Text style={styles.prizeSmall}>Bravo! Allah bless you 🤍</Text>
        </View>
      )}

      {/* QUIZ */}
      {showQuiz && (
        <View>
          <Text style={styles.levelTitle}>Level {currentLevel}</Text>
          <Text style={styles.question}>Q{index+1}. {quizData[currentLevel][index].q}</Text>
          {quizData[currentLevel][index].o.map((opt,i)=>(
            <TouchableOpacity key={i} style={styles.optionBtn} onPress={()=>chooseOption(i)}>
              <Text style={styles.optionText}>{opt}</Text>
            </TouchableOpacity>
          ))}
        </View>
      )}

      {/* POPUP */}
      <Modal visible={popupVisible} transparent animationType="fade">
        <View style={styles.popup}>
          <View style={styles.popupContent}>
            <Text style={styles.popupTitle}>{popupTitle}</Text>
            <Text style={styles.popupMsg}>{popupMsg}</Text>
            <TouchableOpacity style={styles.popupBtn} onPress={()=>setPopupVisible(false)}>
              <Text style={styles.popupBtnText}>Continue</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* BACK BUTTON */}
      <TouchableOpacity style={styles.backBtn} onPress={()=>navigation.goBack()}>
        <Text style={styles.backBtnText}>← Back To Quizzes</Text>
      </TouchableOpacity>

    </View>
  );
}

const styles = StyleSheet.create({
  container:{flex:1,padding:20,backgroundColor:"#d8ddab",paddingTop:60},
  heading:{fontSize:30,fontWeight:"bold",textAlign:"center",marginBottom:30},
  levelGrid:{flexDirection:"row",flexWrap:"wrap",justifyContent:"center"},
  levelBox:{backgroundColor:"#d9e074",padding:20,borderRadius:14,margin:10,width:120,alignItems:"center"},
  locked:{backgroundColor:"#cccccc"},
  levelText:{fontSize:18,color:"white",fontWeight:"bold"},
  levelTitle:{fontSize:26,fontWeight:"bold",marginBottom:15},
  question:{fontSize:20,fontWeight:"500",marginBottom:20},
  optionBtn:{padding:12,backgroundColor:"#e8e9df",marginVertical:6,borderRadius:10,borderWidth:2,borderColor:"#363f02"},
  optionText:{fontSize:18},
  popup:{flex:1,backgroundColor:"rgba(0,0,0,0.6)",justifyContent:"center",alignItems:"center"},
  popupContent:{backgroundColor:"#d8dd97",padding:30,borderRadius:20,width:300,alignItems:"center"},
  popupTitle:{fontSize:22,fontWeight:"bold",marginBottom:15},
  popupMsg:{fontSize:16,textAlign:"center",marginBottom:20},
  popupBtn:{backgroundColor:"#4e4d04",padding:12,borderRadius:10,width:120},
  popupBtnText:{textAlign:"center",color:"white",fontSize:16},
  prizeBox:{alignItems:"center",marginTop:50},
  prizeText:{fontSize:26,fontWeight:"bold"},
  star:{fontSize:50,marginVertical:20},
  prizeSmall:{fontSize:18},

 // ✅ Back Button Styles (thoda neeche)
backBtn: {
  position: "absolute",
  top: "72%", // 65% se neeche, screen ke center ke qareeb
  alignSelf: "center",
  backgroundColor: "#0c417e",
  paddingVertical: 12,
  paddingHorizontal: 28,
  borderRadius: 30,
  elevation: 6
},
backBtnText: {
  color: "white",
  fontSize: 16,
  fontWeight: "bold"
}
});
