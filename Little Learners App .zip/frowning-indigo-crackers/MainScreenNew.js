import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Dimensions, Animated } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useNavigation } from '@react-navigation/native';

const { width, height } = Dimensions.get('window');

export default function App() {
   const navigation = useNavigation();
  const bubbleAnimValues = useRef(Array(25).fill().map(() => new Animated.Value(0))).current;
  const floatAnims = useRef(Array(6).fill().map(() => new Animated.Value(0))).current;

  useEffect(() => {
    bubbleAnimValues.forEach(anim => {
      anim.setValue(height + Math.random() * 200);
      Animated.loop(
        Animated.timing(anim, {
          toValue: -50,
          duration: 5000 + Math.random() * 10000,
          useNativeDriver: true,
        })
      ).start();
    });
  }, []);

  const bubbles = bubbleAnimValues.map((anim, i) => {
    const size = Math.random() * 20 + 10;
    const left = Math.random() * width;
    const colors = ['#ffffff', '#d1f0ff', '#a0e7ff', '#ffffffaa'];
    const backgroundColor = colors[Math.floor(Math.random() * colors.length)];

    return (
      <Animated.View
        key={i}
        style={{
          position: 'absolute',
          width: size,
          height: size,
          borderRadius: size / 2,
          backgroundColor,
          left,
          transform: [{ translateY: anim }],
        }}
      />
    );
  });

  useEffect(() => {
    floatAnims.forEach(anim => {
      Animated.loop(
        Animated.sequence([
          Animated.timing(anim, { toValue: -10, duration: 3000, useNativeDriver: true }),
          Animated.timing(anim, { toValue: 0, duration: 3000, useNativeDriver: true }),
        ])
      ).start();
    });
  }, []);

  const cards = [
    { title: 'Stories', desc: 'Explore interesting Islamic stories for kids, full of morals and inspiration.', btn: 'Read Stories', colors: ['#ff9a9e', '#fad0c4'], route: 'Stories', },
    { title: 'Hadiths', desc: 'Learn valuable Hadiths with simple explanations to understand the teachings.', btn: 'Read Hadiths', colors: ['#a1c4fd', '#c2e9fb'], route: 'Hadiths', },
    { title: 'Duas', desc: 'Discover everyday Duas to recite for protection, guidance, and blessings.', btn: 'Read Duas', colors: ['#fbc2eb', '#a6c1ee'],route: 'Duas' },
    { title: 'Word', desc: 'Learn new Islamic words and their meanings to expand your vocabulary.', btn: 'Read Words', colors: ['#fddb92', '#d1fdff'], route: 'Words'},
    { title: 'Games', desc: 'Have fun with interactive Islamic games designed to teach while you play.', btn: 'Play Games', colors: ['#84fab0', '#8fd3f4'], route: 'Games'},
    { title: 'Quizzes', desc: 'Test your knowledge with fun quizzes about Islamic teachings and stories.', btn: 'Read Quizes', colors: ['#fccb90', '#d57eeb'],route: 'Quizes' },
  ];

  return (
    <LinearGradient
      colors={['#cc4a85', '#3a99c9', '#ccc34f', '#cc5a3f']}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={styles.container}
    >
      {bubbles}

      <ScrollView contentContainerStyle={styles.scrollContainer} showsVerticalScrollIndicator={false}>
        {cards.map((card, index) => (
          <Animated.View
            key={index}
            style={[styles.card, { transform: [{ translateY: floatAnims[index] }] }]}
          >
            <LinearGradient
              colors={card.colors}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={styles.cardGradient}
            >
              <Text style={styles.cardTitle}>{card.title}</Text>
              <Text style={styles.cardDesc}>{card.desc}</Text>
              <TouchableOpacity
  style={styles.cardBtn}
  onPress={() => {
    if (card.route) {
      navigation.navigate(card.route);
    }
  }}
>
                <LinearGradient
                  colors={['#ff4a85', '#3a99c9']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                  style={styles.btnGradient}
                >
                  <Text style={{ color: '#fff', fontWeight: 'bold' }}>{card.btn}</Text>
                </LinearGradient>
              </TouchableOpacity>
            </LinearGradient>

            {/* Smaller top circles slightly lower */}
<View style={[styles.circle, { backgroundColor: card.colors[0], width: 40, height: 40, top: -15, left: 45 }]} />
<View style={[styles.circle, { backgroundColor: card.colors[0], width: 50, height: 50, top: -20, right: 45 }]} />
          </Animated.View>
        ))}
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollContainer: { paddingVertical: 60, alignItems: 'center', paddingBottom: 100 },
  card: {
    width: 300,
    padding: 30,
    borderRadius: 80,
    alignItems: 'center',
    marginVertical: 25,
    shadowColor: '#000',
    shadowOpacity: 0.25,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 5 },
    overflow: 'visible',
  },
  cardGradient: { width: '100%', padding: 25, borderRadius: 80, alignItems: 'center' },
  cardTitle: { fontSize: 22, fontWeight: 'bold', color: '#000', marginBottom: 10, textAlign: 'center' },
  cardDesc: { fontSize: 16, color: '#555', marginBottom: 15, textAlign: 'center' },
  cardBtn: { borderRadius: 25, overflow: 'hidden' },
  btnGradient: { paddingVertical: 12, paddingHorizontal: 25, borderRadius: 25, alignItems: 'center' },
  circle: { position: 'absolute', borderRadius: 100 },
});
