import React from "react";
import { View, Text, StyleSheet, FlatList, TouchableOpacity, Dimensions } from "react-native";
import { LinearGradient } from "expo-linear-gradient";

const { width } = Dimensions.get("window");

// Sample Dua List
const duas = [
  { id: 1, title: "Dua Before Eating" },
  { id: 2, title: "Dua After Eating" },
  { id: 3, title: "Dua Before Sleeping" },
  { id: 4, title: "Dua After Waking Up" },
  { id: 5, title: "Dua Before Studying" },
  { id: 6, title: "Dua After Studying" },
  { id: 7, title: "Dua Entering Home" },
  { id: 8, title: "Dua Leaving Home" },
  { id: 9, title: "Dua Before Travel" },
  { id: 10, title: "Dua After Travel" },
];

export default function Duas({ navigation }) {
  const renderItem = ({ item }) => (
    <LinearGradient
      colors={["#e2d1d1", "#ecc8f1"]}
      style={styles.duaCard}
    >
      <Text style={styles.duaInfo}>
        <Text style={styles.duaNumber}>{item.id}.</Text> {item.title}
      </Text>
    <TouchableOpacity
  style={styles.readBtn}
  onPress={() => navigation.navigate(`Dua${item.id}`)}
>
  <Text style={styles.readBtnText}>let's read</Text>
</TouchableOpacity>


    </LinearGradient>
  );

  return (
    <LinearGradient colors={["#e4bdc9", "#c0a0c5"]} style={styles.container}>
      <Text style={styles.heading}>🌸 Daily Duas</Text>
      <FlatList
        data={duas}
        renderItem={renderItem}
        keyExtractor={(item) => item.id.toString()}
        contentContainerStyle={{ paddingVertical: 20, paddingHorizontal: 10 }}
      />
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  heading: {
    textAlign: "center",
    fontSize: 28,
    paddingVertical: 20,
    color: "#0c0b0c",
    fontWeight: "bold",
  },
  duaCard: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: 18,
    borderRadius: 20,
    marginBottom: 15,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 5,
  },
  duaInfo: {
    fontSize: 16,
    color: "#4a148c",
    fontWeight: "600",
    flex: 1,
    marginRight: 10,
  },
  duaNumber: {
    fontWeight: "bold",
    color: "#6a1b9a",
    marginRight: 5,
  },
  readBtn: {
    backgroundColor: "#ab47bc",
    paddingVertical: 10,
    paddingHorizontal: 18,
    borderRadius: 25,
  },
  readBtnText: {
    color: "white",
    fontWeight: "600",
    fontSize: 14,
  },
});
