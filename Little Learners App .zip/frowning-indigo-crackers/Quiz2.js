import React, { useState } from "react";
import { StyleSheet, Text, View, TouchableOpacity, Modal } from "react-native";

export default function Quiz2Screen({ navigation }) {
  const [unlocked, setUnlocked] = useState(1);
  const [currentLevel, setCurrentLevel] = useState(null);
  const [index, setIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [showQuiz, setShowQuiz] = useState(false);
  const [popup, setPopup] = useState(false);
  const [popupTitle, setPopupTitle] = useState("");
  const [popupMsg, setPopupMsg] = useState("");

  const quizData = {
    1: [
      { q: "Which animal is known as the King of Jungle?", o: ["Lion", "Tiger", "Elephant", "Bear"], a: 0 },
      { q: "Which animal lays eggs?", o: ["Dog", "Cat", "Crocodile", "Cow"], a: 2 },
      { q: "Which animal is the fastest?", o: ["Cheetah", "Lion", "Horse", "Elephant"], a: 0 },
      { q: "Which animal is herbivore?", o: ["Lion", "Deer", "Tiger", "Wolf"], a: 1 },
      { q: "Which animal has a trunk?", o: ["Elephant", "Horse", "Camel", "Dog"], a: 0 },
      { q: "Which animal can fly?", o: ["Penguin", "Eagle", "Ostrich", "Lion"], a: 1 },
      { q: "Largest mammal?", o: ["Elephant", "Blue Whale", "Giraffe", "Shark"], a: 1 },
      { q: "Black & white stripes?", o: ["Zebra", "Tiger", "Cow", "Horse"], a: 0 },
      { q: "Lives in water?", o: ["Dog", "Cat", "Fish", "Cow"], a: 2 },
      { q: "Gives milk?", o: ["Dog", "Cow", "Lion", "Horse"], a: 1 },
    ],
    2: [
      { q: "Which part absorbs water?", o: ["Root", "Leaf", "Stem", "Flower"], a: 0 },
      { q: "Which gives oxygen?", o: ["Cactus", "Tree", "Mushroom", "Fern"], a: 1 },
      { q: "Which part is green?", o: ["Root", "Leaf", "Flower", "Fruit"], a: 1 },
      { q: "Grows in water?", o: ["Cactus", "Lotus", "Rose", "Sunflower"], a: 1 },
      { q: "Makes seeds?", o: ["Leaf", "Flower", "Stem", "Root"], a: 1 },
      { q: "King of fruits?", o: ["Apple", "Mango", "Banana", "Orange"], a: 1 },
      { q: "Stores water?", o: ["Cactus", "Rose", "Mango", "Tulip"], a: 0 },
      { q: "Used for paper?", o: ["Oak", "Bamboo", "Pine", "Rose"], a: 1 },
      { q: "Used in medicine?", o: ["Aloe Vera", "Grass", "Mango", "Sunflower"], a: 0 },
      { q: "Produces nuts?", o: ["Almond", "Rose", "Mango", "Tulip"], a: 0 },
    ],
    3: [
      { q: "Red planet?", o: ["Earth", "Mars", "Venus", "Jupiter"], a: 1 },
      { q: "Closest to Sun?", o: ["Mercury", "Venus", "Earth", "Mars"], a: 0 },
      { q: "Has rings?", o: ["Saturn", "Jupiter", "Neptune", "Mars"], a: 0 },
      { q: "Largest planet?", o: ["Earth", "Jupiter", "Mars", "Venus"], a: 1 },
      { q: "We live on?", o: ["Mars", "Earth", "Venus", "Jupiter"], a: 1 },
      { q: "Morning star?", o: ["Venus", "Mars", "Jupiter", "Mercury"], a: 0 },
      { q: "Farthest planet?", o: ["Neptune", "Mars", "Earth", "Venus"], a: 0 },
      { q: "Blue planet?", o: ["Mars", "Earth", "Venus", "Jupiter"], a: 1 },
      { q: "Spins sideways?", o: ["Uranus", "Neptune", "Saturn", "Jupiter"], a: 0 },
      { q: "Fastest orbit?", o: ["Mercury", "Venus", "Earth", "Mars"], a: 0 },
    ],
    4: [
      { q: "Bones in body?", o: ["206", "205", "210", "200"], a: 0 },
      { q: "Pumps blood?", o: ["Lungs", "Heart", "Kidney", "Liver"], a: 1 },
      { q: "Helps breathe?", o: ["Heart", "Lungs", "Stomach", "Kidney"], a: 1 },
      { q: "Sense of sight?", o: ["Ear", "Nose", "Eye", "Tongue"], a: 2 },
      { q: "Sense of smell?", o: ["Ear", "Nose", "Eye", "Tongue"], a: 1 },
      { q: "Digests food?", o: ["Liver", "Stomach", "Heart", "Lungs"], a: 1 },
      { q: "Hear?", o: ["Ear", "Nose", "Eye", "Hand"], a: 0 },
      { q: "Filters blood?", o: ["Kidney", "Heart", "Liver", "Lungs"], a: 0 },
      { q: "Stores bile?", o: ["Liver", "Gallbladder", "Stomach", "Pancreas"], a: 1 },
      { q: "Fight infection?", o: ["Red", "White", "Platelets", "Plasma"], a: 1 },
    ],
    5: [
      { q: "Highest volcano?", o: ["Earth", "Mars", "Venus", "Jupiter"], a: 1 },
      { q: "Regenerates body?", o: ["Starfish", "Dog", "Cat", "Horse"], a: 0 },
      { q: "Plant makes food?", o: ["Root", "Leaf", "Stem", "Flower"], a: 1 },
      { q: "Humans inhale?", o: ["Oxygen", "Carbon Dioxide", "Nitrogen", "Hydrogen"], a: 0 },
      { q: "Smallest bone?", o: ["Femur", "Stapes", "Tibia", "Radius"], a: 1 },
      { q: "Shortest day?", o: ["Jupiter", "Mercury", "Earth", "Venus"], a: 0 },
      { q: "Largest eggs?", o: ["Ostrich", "Eagle", "Penguin", "Chicken"], a: 0 },
      { q: "Produces insulin?", o: ["Liver", "Pancreas", "Kidney", "Heart"], a: 1 },
      { q: "Cotton from?", o: ["Cotton plant", "Rose", "Mango", "Tulip"], a: 0 },
      { q: "Blue planet?", o: ["Earth", "Mars", "Venus", "Jupiter"], a: 0 },
    ]
  };

  const startLevel = (lv) => {
    setCurrentLevel(lv);
    setIndex(0);
    setScore(0);
    setShowQuiz(true);
  };

  const chooseOption = (i) => {
    if (i === quizData[currentLevel][index].a) setScore(score + 1);
    next();
  };

  const next = () => {
    if (index < 9) {
      setIndex(index + 1);
    } else {
      finishLevel();
    }
  };

  const finishLevel = () => {
    const pass = score >= 7;
    if (pass) {
      if (currentLevel === 5) {
        setPopupTitle("🎉 WELL DONE 🎉");
        setPopupMsg(`You completed all 5 levels!\nScore: ${score}/10`);
        setUnlocked(6);
      } else {
        setPopupTitle(`Level ${currentLevel} Passed`);
        setPopupMsg(`Score: ${score}/10\nNext Level Unlocked`);
        if (unlocked === currentLevel) setUnlocked(unlocked + 1);
      }
    } else {
      setPopupTitle(`Level ${currentLevel} Failed`);
      setPopupMsg(`Score: ${score}/10\nTry Again`);
    }
    setPopup(true);
    setShowQuiz(false);
  };

  return (
    <View style={styles.container}>
      {!showQuiz && unlocked < 6 && (
        <View>
          <Text style={styles.heading}>🔬 Science Quiz</Text>
          <View style={styles.levelGrid}>
            {[1,2,3,4,5].map(lv => (
              <TouchableOpacity
                key={lv}
                disabled={lv > unlocked}
                style={[styles.levelBox, lv > unlocked && styles.locked]}
                onPress={() => startLevel(lv)}>
                <Text style={styles.levelText}>{lv > unlocked ? "🔒" : ""} Level {lv}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      )}

      {unlocked === 6 && (
        <View style={styles.prizeBox}>
          <Text style={styles.prizeText}>🏆 YOU PASSED ALL LEVELS 🏆</Text>
          <Text style={styles.star}>⭐⭐⭐</Text>
          <Text style={styles.prizeSmall}>Great Job! Allah Bless You 🤍</Text>
        </View>
      )}

      {showQuiz && (
        <View>
          <Text style={styles.levelTitle}>Level {currentLevel}</Text>
          <Text style={styles.question}>
            Q{index + 1}. {quizData[currentLevel][index].q}
          </Text>
          {quizData[currentLevel][index].o.map((opt, i) => (
            <TouchableOpacity
              key={i}
              onPress={() => chooseOption(i)}
              style={styles.optionBtn}>
              <Text style={styles.optionText}>{opt}</Text>
            </TouchableOpacity>
          ))}
        </View>
      )}

      <Modal visible={popup} transparent animationType="fade">
        <View style={styles.popup}>
          <View style={styles.popupContent}>
            <Text style={styles.popupTitle}>{popupTitle}</Text>
            <Text style={styles.popupMsg}>{popupMsg}</Text>
            <TouchableOpacity onPress={() => setPopup(false)} style={styles.popupBtn}>
              <Text style={styles.popupBtnText}>Continue</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* ✅ Back Button */}
      <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
        <Text style={styles.backBtnText}>← Back To Quizzes</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: "#d7f2f4", paddingTop: 60 },
  heading: { fontSize: 30, fontWeight: "bold", textAlign: "center", marginBottom: 30 },
  levelGrid: { flexDirection: "row", flexWrap: "wrap", justifyContent: "center" },
  levelBox: { backgroundColor: "#4fb0c6", padding: 20, borderRadius: 14, margin: 10, width: 120, alignItems: "center" },
  locked: { backgroundColor: "#cccccc" },
  levelText: { fontSize: 18, color: "white", fontWeight: "bold" },
  levelTitle: { fontSize: 26, fontWeight: "bold", marginBottom: 15 },
  question: { fontSize: 20, fontWeight: "500", marginBottom: 20 },
  optionBtn: { padding: 12, backgroundColor: "#e0f5ff", marginVertical: 6, borderRadius: 10, borderWidth: 2, borderColor: "#046c82" },
  optionText: { fontSize: 18 },
  popup: { flex: 1, backgroundColor: "rgba(0,0,0,0.6)", justifyContent: "center", alignItems: "center" },
  popupContent: { backgroundColor: "#98d6db", padding: 30, borderRadius: 20, width: 300, alignItems: "center" },
  popupTitle: { fontSize: 22, fontWeight: "bold", marginBottom: 15 },
  popupMsg: { fontSize: 16, textAlign: "center", marginBottom: 20 },
  popupBtn: { backgroundColor: "#034e5e", padding: 12, borderRadius: 10, width: 120 },
  popupBtnText: { textAlign: "center", color: "white", fontSize: 16 },
  prizeBox: { alignItems: "center", marginTop: 50 },
  prizeText: { fontSize: 26, fontWeight: "bold" },
  star: { fontSize: 50, marginVertical: 20 },
  prizeSmall: { fontSize: 18 },

  // ✅ Back Button Styles (thoda neeche)
backBtn: {
  position: "absolute",
  top: "72%", // 65% se neeche, screen ke center ke qareeb
  alignSelf: "center",
  backgroundColor: "#0c417e",
  paddingVertical: 12,
  paddingHorizontal: 28,
  borderRadius: 30,
  elevation: 6
},
backBtnText: {
  color: "white",
  fontSize: 16,
  fontWeight: "bold"
}
});
