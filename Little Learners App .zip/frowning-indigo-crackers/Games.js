import React from 'react';
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

const { width } = Dimensions.get('window');

const GameCard = ({ title, description, colors, onPress }) => {
  return (
    <TouchableOpacity
      activeOpacity={0.8}
      style={styles.cardContainer}
      onPress={onPress}
    >
      <LinearGradient
        colors={colors}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.gameCard}
      >
        <Text style={styles.cardTitle}>{title}</Text>
        <Text style={styles.cardDescription}>{description}</Text>

        <View style={styles.buttonContainer}>
          <LinearGradient colors={['#ff6f61', '#ffd36b']} style={styles.button}>
            <Text style={styles.buttonText}>Play</Text>
          </LinearGradient>
        </View>
      </LinearGradient>
    </TouchableOpacity>
  );
};

export default function Games({ navigation }) {
  const games = [
    { id: 1, title: "✨Light Explorer✨", desc: "🧩 Piece together glowing words to unlock Surah puzzle!", colors: ['#ff9a9e', '#fad0c4'] },
    { id: 2, title: "📖Verse Quest📖", desc: "🔎 Match verses with meanings and become a Quran hero!", colors: ['#a1c4fd', '#c2e9fb'] },
    { id: 3, title: "🌸Blessing Sorter🌸", desc: "🙌 Spot when to say Bismillah or Alhamdulillah!", colors: ['#ffecd2', '#fcb69f'] },
    { id: 4, title: "🌟Faith Challenge🌟", desc: "💡 Test your skills on the pillars of Islam!", colors: ['#89f7fe', '#66a6ff'] },
    { id: 5, title: "💧Wudu Steps💧", desc: "🚿 Arrange the steps of wudu in the right order!", colors: ['#fbc2eb', '#a6c1ee'] },
    { id: 6, title: "🌙Calendar Race🌙", desc: "🏃 Put the Islamic months in order and race!", colors: ['#ff9a9e', '#fecfef'] },
    { id: 7, title: "🕌Pillar Match🕌", desc: "🧠 Match English and Arabic names of the pillars!", colors: ['#a1c4fd', '#c2e9fb'] },
    { id: 8, title: "🏞️Hajj Puzzle🏞️", desc: "🕋 Complete the Hajj puzzle and travel the journey!", colors: ['#fdfbfb', '#ebedee'] },
    { id: 9, title: "🙏Prayer Puzzle🙏", desc: "🧩 Put together the prayer puzzle and learn!", colors: ['#ffdde1', '#ee9ca7'] },
    { id: 10, title: "🔍Word Hunt🔍", desc: "✨ Search for the pillars of Islam in a fun word maze!", colors: ['#89f7fe', '#66a6ff'] },
  ];

  const handlePress = (id) => {
    navigation.navigate(`Game${id}`);
  };

  return (
    <LinearGradient colors={['#2a5298', '#6a11cb', '#ff9a76']} style={styles.container}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <Text style={styles.headerText}>🎉 Fun is Here — Let's Play! 🎮</Text>

        <View style={styles.grid}>
          {games.map((item) => (
            <GameCard
              key={item.id}
              title={item.title}
              description={item.desc}
              colors={item.colors}
              onPress={() => handlePress(item.id)}
            />
          ))}
        </View>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    alignItems: 'center',
    paddingVertical: 50,
    paddingHorizontal: 10,
  },
  headerText: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#fff',
    textAlign: 'center',
    marginBottom: 30,
    textShadowColor: 'rgba(0,0,0,0.4)',
    textShadowOffset: { width: 2, height: 2 },
    textShadowRadius: 6,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    // gap is not supported in React Native, we use margin instead
  },
  cardContainer: {
    margin: 10, // replaces gap
  },
  gameCard: {
    width: width * 0.42,
    height: width * 0.42,
    borderRadius: width * 0.21,
    padding: 15,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 5,
  },
  cardTitle: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
  },
  cardDescription: {
    fontSize: 10,
    color: '#000',
    textAlign: 'center',
    marginTop: 5,
  },
  buttonContainer: {
    marginTop: 10,
  },
  button: {
    paddingVertical: 6,
    paddingHorizontal: 15,
    borderRadius: 20,
  },
  buttonText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: 'bold',
  },
});
