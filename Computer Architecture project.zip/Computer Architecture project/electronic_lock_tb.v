module electronic_lock_tb;

    reg clk;
    reg reset;
    reg [7:0] password;
    wire unlock;

    electronic_lock uut (
        .clk(clk),
        .reset(reset),
        .password(password),
        .unlock(unlock)
    );

    // Clock generation
    always #5 clk = ~clk;

    initial begin
        clk = 0;
        reset = 1;
        password = 8'b00000000;

        #10 reset = 0;

        // Wrong password
        #10 password = 8'b11111111;
        #10;

        // Correct password
        #10 password = 8'b10101010;
        #10;

        // Another wrong password
        #10 password = 8'b00110011;
        #10;

        $stop;
    end

endmodule
