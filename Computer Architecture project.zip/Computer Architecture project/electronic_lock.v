module electronic_lock (
    input clk,
    input reset,
    input [7:0] password,
    output reg unlock
);
    parameter CORRECT_PASSWORD = 8'b10101010;
    always @(posedge clk or posedge reset) begin
        if (reset) begin
            unlock <= 0;
        end
        else begin
            if (password == CORRECT_PASSWORD)
                unlock <= 1;
            else
                unlock <= 0;
        end
    end
endmodule
